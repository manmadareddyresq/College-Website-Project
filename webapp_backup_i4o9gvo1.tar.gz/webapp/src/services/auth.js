/**
 * Authentication Service
 * Handles Firebase Auth operations
 */

import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updatePassword,
} from 'firebase/auth';
import { auth } from './firebase';

// Admin emails whitelist (configure in .env)
const ADMIN_EMAILS = [
  'admin@ucmh.edu.in',
  'principal@ucmh.edu.in',
  import.meta.env.VITE_ADMIN_EMAIL,
].filter(Boolean);

export const loginAdmin = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Check if user is admin
    if (!ADMIN_EMAILS.includes(user.email)) {
      await signOut(auth);
      throw new Error('You do not have admin privileges.');
    }

    return user;
  } catch (error) {
    throw new Error(getAuthErrorMessage(error.code) || error.message);
  }
};

export const logoutAdmin = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    throw new Error('Failed to sign out. Please try again.');
  }
};

export const getCurrentUser = () => auth.currentUser;

export const onAuthChange = (callback) => {
  return onAuthStateChanged(auth, callback);
};

export const isAdmin = (user) => {
  if (!user) return false;
  return ADMIN_EMAILS.includes(user.email);
};

// Human-readable error messages
const getAuthErrorMessage = (code) => {
  const messages = {
    'auth/user-not-found': 'No account found with this email.',
    'auth/wrong-password': 'Incorrect password. Please try again.',
    'auth/invalid-email': 'Invalid email address.',
    'auth/too-many-requests': 'Too many failed attempts. Please try again later.',
    'auth/network-request-failed': 'Network error. Check your connection.',
    'auth/invalid-credential': 'Invalid credentials. Please check your email and password.',
  };
  return messages[code] || null;
};

/**
 * Firestore Service Layer
 * Provides CRUD operations for all collections
 */

import {
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  onSnapshot,
} from 'firebase/firestore';
import { db } from './firebase';

// ─── Generic CRUD ────────────────────────────────────────────────────────────

export const getCollection = async (collectionName, conditions = []) => {
  try {
    const ref = collection(db, collectionName);
    let q = ref;
    if (conditions.length > 0) {
      q = query(ref, ...conditions);
    }
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (error) {
    console.error(`Error fetching ${collectionName}:`, error);
    throw error;
  }
};

export const getDocument = async (collectionName, docId) => {
  try {
    const ref = doc(db, collectionName, docId);
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    return { id: snap.id, ...snap.data() };
  } catch (error) {
    console.error(`Error fetching document ${docId}:`, error);
    throw error;
  }
};

export const createDocument = async (collectionName, data) => {
  try {
    const ref = collection(db, collectionName);
    const docRef = await addDoc(ref, {
      ...data,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    console.error(`Error creating document in ${collectionName}:`, error);
    throw error;
  }
};

export const updateDocument = async (collectionName, docId, data) => {
  try {
    const ref = doc(db, collectionName, docId);
    await updateDoc(ref, {
      ...data,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    console.error(`Error updating document ${docId}:`, error);
    throw error;
  }
};

export const deleteDocument = async (collectionName, docId) => {
  try {
    const ref = doc(db, collectionName, docId);
    await deleteDoc(ref);
  } catch (error) {
    console.error(`Error deleting document ${docId}:`, error);
    throw error;
  }
};

// ─── News ─────────────────────────────────────────────────────────────────────

export const getNews = async (limitCount = 10) => {
  return getCollection('news', [
    orderBy('createdAt', 'desc'),
    limit(limitCount),
  ]);
};

export const createNews = (data) => createDocument('news', data);
export const updateNews = (id, data) => updateDocument('news', id, data);
export const deleteNews = (id) => deleteDocument('news', id);

// ─── Events ───────────────────────────────────────────────────────────────────

export const getEvents = async (limitCount = 10) => {
  return getCollection('events', [
    orderBy('eventDate', 'desc'),
    limit(limitCount),
  ]);
};

export const createEvent = (data) => createDocument('events', data);
export const updateEvent = (id, data) => updateDocument('events', id, data);
export const deleteEvent = (id) => deleteDocument('events', id);

// ─── Faculty ──────────────────────────────────────────────────────────────────

export const getFaculty = async () => {
  return getCollection('faculty', [orderBy('order', 'asc')]);
};

export const createFaculty = (data) => createDocument('faculty', data);
export const updateFaculty = (id, data) => updateDocument('faculty', id, data);
export const deleteFaculty = (id) => deleteDocument('faculty', id);

// ─── Gallery ──────────────────────────────────────────────────────────────────

export const getGallery = async () => {
  return getCollection('gallery', [orderBy('createdAt', 'desc')]);
};

export const createGalleryItem = (data) => createDocument('gallery', data);
export const deleteGalleryItem = (id) => deleteDocument('gallery', id);

// ─── Courses ──────────────────────────────────────────────────────────────────

export const getCourses = async () => {
  return getCollection('courses', [orderBy('order', 'asc')]);
};

export const createCourse = (data) => createDocument('courses', data);
export const updateCourse = (id, data) => updateDocument('courses', id, data);
export const deleteCourse = (id) => deleteDocument('courses', id);

// ─── Feedback ─────────────────────────────────────────────────────────────────

export const submitFeedback = (data) => createDocument('feedback', data);
export const getFeedback = async () => {
  return getCollection('feedback', [orderBy('createdAt', 'desc')]);
};

// ─── Circulars ────────────────────────────────────────────────────────────────

export const getCirculars = async () => {
  return getCollection('circulars', [orderBy('createdAt', 'desc')]);
};

export const createCircular = (data) => createDocument('circulars', data);
export const deleteCircular = (id) => deleteDocument('circulars', id);

// ─── Real-time listener ───────────────────────────────────────────────────────

export const subscribeToCollection = (collectionName, callback, conditions = []) => {
  const ref = collection(db, collectionName);
  const q = conditions.length > 0 ? query(ref, ...conditions) : ref;
  return onSnapshot(q, (snapshot) => {
    const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    callback(data);
  });
};

import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import {
  GraduationCap, Users, Trophy, BookOpen, ArrowRight, Play,
  Star, MapPin, Phone, Mail, ChevronRight, Award, Globe,
  TrendingUp, Building2, Calendar, Newspaper, CheckCircle,
  Briefcase, FlaskConical, Heart
} from 'lucide-react';
import { getNews, getEvents } from '../services/firestore';

// ─── Static Data ──────────────────────────────────────────────────────────────
const STATS = [
  { value: '25+', label: 'Years of Excellence', icon: Award },
  { value: '5000+', label: 'Alumni Network', icon: Users },
  { value: '95%', label: 'Placement Rate', icon: Briefcase },
  { value: '50+', label: 'Expert Faculty', icon: GraduationCap },
  { value: '10+', label: 'Industry Partners', icon: Building2 },
  { value: '3', label: 'International Collaborations', icon: Globe },
];

const COURSES = [
  { title: 'MBA (Regular)', tag: 'ICET', desc: 'Two-year full-time MBA program affiliated to JNTUH', color: 'from-blue-600 to-blue-800', path: '/courses' },
  { title: 'MBA (Part-Time)', tag: 'PTPG', desc: 'Flexible MBA for working professionals', color: 'from-purple-600 to-purple-800', path: '/courses' },
  { title: 'MBA + CMU', tag: 'International', desc: 'Dual credential with Carnegie Mellon University, USA', color: 'from-indigo-600 to-indigo-800', path: '/courses' },
  { title: 'PhD Program', tag: 'Research', desc: 'Doctoral research in management sciences', color: 'from-teal-600 to-teal-800', path: '/courses' },
  { title: 'BBA (Regular)', tag: 'Undergraduate', desc: '3-year undergraduate business program', color: 'from-orange-600 to-orange-800', path: '/courses' },
  { title: 'BBA Data Analytics', tag: 'Specialized', desc: 'BBA with data analytics specialization', color: 'from-rose-600 to-rose-800', path: '/courses' },
];

const WHY_CHOOSE = [
  { icon: Award, title: 'JNTUH Affiliation', desc: 'Prestigious university affiliation ensuring quality education' },
  { icon: Globe, title: 'Global Partnerships', desc: 'Collaborations with international universities including CMU, USA' },
  { icon: Briefcase, title: '95% Placements', desc: 'Excellent placement record with top MNCs and startups' },
  { icon: FlaskConical, title: 'Research Excellence', desc: 'Active research culture with funded projects' },
  { icon: Users, title: 'Expert Faculty', desc: '50+ experienced professors and industry practitioners' },
  { icon: Heart, title: 'Holistic Development', desc: 'Sports, arts, and extracurricular excellence' },
];

// ─── Animated Counter ─────────────────────────────────────────────────────────
function AnimatedStat({ value, label, icon: Icon }) {
  return (
    <motion.div
      whileHover={{ scale: 1.03 }}
      className="text-center p-6 glass rounded-2xl border border-white/20"
    >
      <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mx-auto mb-3">
        <Icon size={24} className="text-white/80" />
      </div>
      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-3xl font-black text-white mb-1"
      >
        {value}
      </motion.p>
      <p className="text-sm text-primary-200">{label}</p>
    </motion.div>
  );
}

export default function Home() {
  const [news, setNews] = useState([]);
  const [events, setEvents] = useState([]);
  const [loadingNews, setLoadingNews] = useState(true);
  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 400], [0, 100]);
  const heroOpacity = useTransform(scrollY, [0, 300], [1, 0.3]);

  useEffect(() => {
    getNews(4).then(data => { setNews(data); setLoadingNews(false); }).catch(() => setLoadingNews(false));
    getEvents(3).then(data => setEvents(data));
  }, []);

  return (
    <div className="min-h-screen">
      {/* ── Hero Section ─────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary-950 via-primary-900 to-gray-900">
        {/* Animated background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{ scale: [1, 1.1, 1], rotate: [0, 5, 0] }}
            transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-0 left-0 w-full h-full opacity-10"
            style={{
              background: 'radial-gradient(ellipse at 20% 50%, #3b82f6 0%, transparent 50%), radial-gradient(ellipse at 80% 20%, #8b5cf6 0%, transparent 50%)',
            }}
          />
          <div className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)',
              backgroundSize: '40px 40px',
            }}
          />
          {/* Floating orbs */}
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full bg-primary-400/10 blur-2xl"
              style={{
                width: 100 + i * 80,
                height: 100 + i * 80,
                left: `${10 + i * 20}%`,
                top: `${10 + i * 15}%`,
              }}
              animate={{
                y: [0, -30, 0],
                x: [0, 15, 0],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 8 + i * 2,
                repeat: Infinity,
                ease: 'easeInOut',
                delay: i * 1.5,
              }}
            />
          ))}
        </div>

        <motion.div
          style={{ y: heroY, opacity: heroOpacity }}
          className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full text-sm text-primary-200 mb-6"
          >
            <Star size={14} className="text-gold-400 fill-gold-400" />
            JNTUH Affiliated | Est. 1998
            <Star size={14} className="text-gold-400 fill-gold-400" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white mb-6 leading-[1.1]"
          >
            University College of
            <br />
            <span className="bg-gradient-to-r from-primary-300 via-accent-300 to-primary-200 bg-clip-text text-transparent">
              Management Hyderabad
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-lg sm:text-xl text-primary-200 max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Shaping tomorrow's business leaders through excellence in education,
            research, and innovation. JNTUH affiliated | Kukatpally, Hyderabad
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link to="/courses" className="btn-primary text-base px-8 py-4 shadow-glow-lg">
              Explore Programs
              <ArrowRight size={18} />
            </Link>
            <Link to="/about" className="inline-flex items-center gap-2 px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white font-semibold rounded-xl border border-white/20 transition-all duration-200 text-base">
              <Play size={16} className="fill-white" />
              About UCMH
            </Link>
          </motion.div>

          {/* Quick info pills */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="flex flex-wrap items-center justify-center gap-4 mt-12"
          >
            {[
              { icon: MapPin, text: 'Kukatpally, Hyderabad' },
              { icon: Phone, text: '+91 40 2345 6789' },
              { icon: Mail, text: 'info@ucmh.edu.in' },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-2 text-sm text-primary-300">
                <Icon size={14} />
                {text}
              </div>
            ))}
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-primary-400"
        >
          <span className="text-xs">Scroll</span>
          <div className="w-5 h-8 rounded-full border-2 border-primary-500 flex items-start justify-center p-1">
            <div className="w-1.5 h-2.5 bg-primary-400 rounded-full animate-bounce" />
          </div>
        </motion.div>
      </section>

      {/* ── Stats ────────────────────────────────────────────────── */}
      <section className="bg-gradient-to-r from-primary-800 to-primary-900 py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {STATS.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <AnimatedStat {...stat} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Highlights / Notice Board ─────────────────────────────── */}
      <section className="py-10 bg-primary-50 dark:bg-primary-950/30 border-b border-primary-100 dark:border-primary-900/50">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center gap-4">
          <span className="bg-primary-600 text-white text-xs font-bold px-4 py-2 rounded-full uppercase tracking-wider shrink-0">
            📢 Notice
          </span>
          <div className="overflow-hidden flex-1">
            <motion.div
              animate={{ x: ['100%', '-100%'] }}
              transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
              className="whitespace-nowrap text-sm text-gray-700 dark:text-gray-300 font-medium"
            >
              🎓 MBA Admissions Open 2025-26 — Apply Now via ICET &nbsp;|&nbsp; 🌟 UCMH × Carnegie Mellon University Collaboration Renewed &nbsp;|&nbsp; 🏆 100% Placement in Batch 2024 &nbsp;|&nbsp; 📚 New BBA Data Analytics Program Launched &nbsp;|&nbsp; 🔬 Research Grant Approved — Apply Now
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Courses ──────────────────────────────────────────────── */}
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="badge badge-primary text-xs mb-3">Academic Programs</span>
            <h2 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white mb-4">
              Courses We <span className="gradient-text">Offer</span>
            </h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-xl mx-auto">
              Industry-aligned programs designed to build future-ready business leaders
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {COURSES.map((course, i) => (
              <motion.div
                key={course.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link to={course.path} className="group block">
                  <div className="card-hover h-full overflow-hidden">
                    <div className={`h-3 bg-gradient-to-r ${course.color}`} />
                    <div className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <span className={`badge bg-gradient-to-r ${course.color} text-white`}>{course.tag}</span>
                        <ArrowRight size={16} className="text-gray-400 group-hover:text-primary-600 group-hover:translate-x-1 transition-all" />
                      </div>
                      <h3 className="font-bold text-gray-900 dark:text-white text-lg mb-2">{course.title}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{course.desc}</p>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-10">
            <Link to="/courses" className="btn-primary">
              View All Programs <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* ── Why Choose UCMH ──────────────────────────────────────── */}
      <section className="section-padding bg-gray-50 dark:bg-gray-900">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="badge badge-primary text-xs mb-3">Why UCMH</span>
              <h2 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white mb-6">
                A Legacy of <span className="gradient-text">Excellence</span>
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-8 leading-relaxed">
                University College of Management Hyderabad stands as a beacon of quality education
                in Telangana. Our commitment to academic rigor, industry relevance, and holistic
                development makes us the preferred choice for management education.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Link to="/about" className="btn-primary">Learn More <ArrowRight size={16} /></Link>
                <Link to="/contact" className="btn-secondary">Contact Us</Link>
              </div>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {WHY_CHOOSE.map((item, i) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="card p-5 hover:shadow-lg transition-shadow"
                  >
                    <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center mb-3">
                      <Icon size={20} className="text-primary-600 dark:text-primary-400" />
                    </div>
                    <h3 className="font-semibold text-gray-900 dark:text-white text-sm mb-1">{item.title}</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">{item.desc}</p>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* ── News & Events ─────────────────────────────────────────── */}
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* News */}
            <div>
              <div className="flex items-center justify-between mb-8">
                <div>
                  <span className="badge badge-primary text-xs mb-2 block">Latest</span>
                  <h2 className="text-2xl font-black text-gray-900 dark:text-white">News Updates</h2>
                </div>
                <Link to="/news" className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1">
                  View all <ChevronRight size={14} />
                </Link>
              </div>

              {loadingNews ? (
                <div className="space-y-4">
                  {[1,2,3].map(i => (
                    <div key={i} className="animate-pulse flex gap-4 p-4 card">
                      <div className="skeleton w-16 h-16 rounded-xl shrink-0" />
                      <div className="flex-1 space-y-2">
                        <div className="skeleton h-4 w-3/4" />
                        <div className="skeleton h-3 w-full" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : news.length > 0 ? (
                <div className="space-y-4">
                  {news.map((item, i) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.08 }}
                      className="card-hover p-4 flex gap-4"
                    >
                      <div className="w-14 h-14 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center shrink-0">
                        <Newspaper size={20} className="text-primary-600 dark:text-primary-400" />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900 dark:text-white text-sm mb-1 line-clamp-2">{item.title}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-1">{item.summary}</p>
                        <p className="text-xs text-primary-600 dark:text-primary-400 mt-1">
                          {item.createdAt?.toDate?.()?.toLocaleDateString?.() || 'Recent'}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {[
                    { title: 'MBA Admissions Open 2025-26', summary: 'Applications now open for MBA program through ICET', date: 'March 2025' },
                    { title: 'Industry Expert Lecture Series', summary: 'Eminent speakers from top MNCs visiting UCMH campus', date: 'March 2025' },
                    { title: 'Annual Sports Meet 2025', summary: 'Annual inter-college sports championship announced', date: 'Feb 2025' },
                    { title: 'Research Excellence Award', summary: 'UCMH faculty wins national research award', date: 'Feb 2025' },
                  ].map((item, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.08 }}
                      className="card-hover p-4 flex gap-4"
                    >
                      <div className="w-14 h-14 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center shrink-0">
                        <Newspaper size={20} className="text-primary-600 dark:text-primary-400" />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900 dark:text-white text-sm mb-1">{item.title}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{item.summary}</p>
                        <p className="text-xs text-primary-600 dark:text-primary-400 mt-1">{item.date}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Events */}
            <div>
              <div className="flex items-center justify-between mb-8">
                <div>
                  <span className="badge badge-warning text-xs mb-2 block">Upcoming</span>
                  <h2 className="text-2xl font-black text-gray-900 dark:text-white">Events</h2>
                </div>
                <Link to="/events" className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1">
                  View all <ChevronRight size={14} />
                </Link>
              </div>

              <div className="space-y-4">
                {[
                  { title: 'Management Conclave 2025', date: 'April 10, 2025', venue: 'Main Auditorium', color: 'bg-blue-500' },
                  { title: 'Alumni Meet 2025', date: 'April 25, 2025', venue: 'Conference Hall', color: 'bg-purple-500' },
                  { title: 'Business Quiz Competition', date: 'May 5, 2025', venue: 'Seminar Hall A', color: 'bg-green-500' },
                  { title: 'International Conference on Mgmt', date: 'May 20, 2025', venue: 'Main Auditorium', color: 'bg-orange-500' },
                ].map((event, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.08 }}
                    className="card-hover p-4 flex gap-4 items-start"
                  >
                    <div className={`${event.color} text-white rounded-xl px-3 py-2 text-center shrink-0 min-w-[56px]`}>
                      <p className="text-xs font-bold">{event.date.split(' ')[0]}</p>
                      <p className="text-lg font-black leading-none">{event.date.split(' ')[1]?.replace(',', '')}</p>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white text-sm mb-1">{event.title}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                        <MapPin size={11} /> {event.venue}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────── */}
      <section className="py-20 bg-gradient-to-br from-primary-900 via-primary-800 to-primary-950 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }}
        />
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <span className="badge bg-white/20 text-white text-xs mb-4">Join UCMH</span>
            <h2 className="text-3xl sm:text-5xl font-black text-white mb-6">
              Start Your Journey to
              <br />
              <span className="text-primary-200">Business Excellence</span>
            </h2>
            <p className="text-primary-200 text-lg mb-10 max-w-xl mx-auto">
              Apply now for the 2025-26 academic year and take the first step
              towards a rewarding management career.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="https://icet.tsche.ac.in"
                target="_blank"
                rel="noreferrer"
                className="btn-primary bg-white text-primary-800 hover:bg-gray-100 shadow-lg px-8 py-4 text-base"
              >
                Apply via ICET <ArrowRight size={18} />
              </a>
              <Link to="/contact" className="inline-flex items-center gap-2 px-8 py-4 border-2 border-white/30 hover:bg-white/10 text-white font-semibold rounded-xl transition-all duration-200 text-base">
                Contact Admissions
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

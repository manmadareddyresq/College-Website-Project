import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, TrendingUp, Users, Award, Building2, ArrowRight, Star } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const COMPANIES = ['TCS', 'Infosys', 'Wipro', 'Deloitte', 'KPMG', 'PwC', 'Amazon', 'Microsoft', 'Accenture', 'IBM', 'Cognizant', 'HCL'];
const STATS = [
  { value: '95%', label: 'Overall Placement', icon: TrendingUp },
  { value: '8.5 LPA', label: 'Avg. Package', icon: Award },
  { value: '24 LPA', label: 'Highest Package', icon: Star },
  { value: '150+', label: 'Recruiters', icon: Building2 },
];

export default function Placements() {
  return (
    <div>
      <PageHeader
        title="Placement Cell"
        subtitle="Our dedicated placement cell connects students with top employers across India and globally"
        breadcrumbs={[{ label: 'Placement Cell' }]}
        icon={Briefcase}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
            {STATS.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.label} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="card p-6 text-center hover:shadow-xl transition-shadow"
                >
                  <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Icon size={22} className="text-primary-600 dark:text-primary-400" />
                  </div>
                  <p className="text-3xl font-black text-primary-600 dark:text-primary-400">{s.value}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{s.label}</p>
                </motion.div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-6">Our Placement <span className="gradient-text">Approach</span></h2>
              <div className="space-y-4">
                {[
                  { step: '1', title: 'Career Counseling', desc: 'Individual career counseling sessions from Day 1 to align academics with career goals' },
                  { step: '2', title: 'Skill Development', desc: 'Dedicated programs for aptitude, communication, GD, PI, and technical skills' },
                  { step: '3', title: 'Mock Drives', desc: 'Regular mock placement drives with industry professionals for real experience' },
                  { step: '4', title: 'Campus Recruitment', desc: 'On-campus recruitment drives from 150+ companies every year' },
                  { step: '5', title: 'Post-Placement Support', desc: 'Alumni network and mentorship for career growth beyond placement' },
                ].map(item => (
                  <div key={item.step} className="flex gap-4">
                    <div className="w-8 h-8 bg-primary-600 text-white rounded-full flex items-center justify-center text-sm font-bold shrink-0">{item.step}</div>
                    <div>
                      <h4 className="font-semibold text-gray-900 dark:text-white">{item.title}</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-6">Top Recruiters</h2>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {COMPANIES.map((c, i) => (
                  <motion.div key={c} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="card p-4 text-center hover:shadow-md transition-shadow"
                  >
                    <div className="w-10 h-10 bg-gradient-to-br from-primary-100 to-primary-200 dark:from-primary-900/40 dark:to-primary-800/40 rounded-xl flex items-center justify-center mx-auto mb-2">
                      <Building2 size={16} className="text-primary-600 dark:text-primary-400" />
                    </div>
                    <p className="text-xs font-bold text-gray-900 dark:text-white">{c}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="bg-gradient-to-r from-primary-900 to-primary-700 rounded-3xl p-8 text-center text-white">
            <h3 className="text-2xl font-black mb-3">Want to Recruit at UCMH?</h3>
            <p className="text-primary-200 mb-6">Connect with our placement cell to schedule a campus drive or internship program</p>
            <a href="mailto:placements@ucmh.edu.in" className="inline-flex items-center gap-2 bg-white text-primary-800 hover:bg-gray-100 font-bold px-6 py-3 rounded-xl transition-colors">
              Contact Placement Cell <ArrowRight size={16} />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

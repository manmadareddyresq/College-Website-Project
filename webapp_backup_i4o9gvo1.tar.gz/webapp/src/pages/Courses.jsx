import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Clock, Users, Award, Globe, BookOpen, ChevronDown, CheckCircle, ArrowRight } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const COURSES = [
  {
    id: 'mba-regular',
    title: 'MBA (Regular)',
    tag: 'ICET',
    duration: '2 Years',
    seats: '120',
    eligibility: 'Any Graduate (ICET Qualified)',
    color: 'from-blue-600 to-blue-800',
    icon: '🎓',
    desc: 'The flagship MBA program offers specializations in Finance, Marketing, HR, Operations, and IT Management. The JNTUH-affiliated program is recognized for its industry-relevant curriculum and excellent placement support.',
    highlights: [
      'JNTUH Affiliated — NAAC Accredited',
      'Specializations: Finance, Marketing, HR, Operations, IT',
      'Industry-integrated curriculum',
      'Guest lectures by industry professionals',
      '95%+ placement support',
      'Case studies and live projects',
    ],
    fee: '₹80,000/year',
    intake: 'July–August',
  },
  {
    id: 'mba-ptpg',
    title: 'MBA (Part-Time PTPG)',
    tag: 'PTPG',
    duration: '3 Years',
    seats: '60',
    eligibility: 'Working Professionals with 2+ years experience',
    color: 'from-purple-600 to-purple-800',
    icon: '💼',
    desc: 'The Part-Time MBA (PTPG) is designed for working professionals seeking to enhance their managerial skills without interrupting their careers. Classes are held on weekends and evenings.',
    highlights: [
      'Weekend and evening classes',
      'Flexible learning schedule',
      'Same JNTUH curriculum as regular MBA',
      'Industry practitioner faculty',
      'Network with working professionals',
      'Career advancement focused',
    ],
    fee: '₹60,000/year',
    intake: 'July–August',
  },
  {
    id: 'mba-cmu',
    title: 'MBA + CMU Collaboration',
    tag: 'International',
    duration: '2 Years',
    seats: '30',
    eligibility: 'Any Graduate + ICET/GMAT',
    color: 'from-indigo-600 to-indigo-800',
    icon: '🌍',
    desc: 'An exclusive international collaboration with Carnegie Mellon University (CMU), USA, offering students dual credentials and exposure to global business practices and CMU\'s world-renowned faculty.',
    highlights: [
      'Dual credential — UCMH + CMU Certificate',
      'Joint curriculum with CMU Tepper School',
      'International faculty guest sessions',
      'Global case studies and projects',
      'Access to CMU alumni network',
      'International internship opportunities',
    ],
    fee: '₹1,50,000/year',
    intake: 'July–August',
  },
  {
    id: 'phd',
    title: 'PhD Program',
    tag: 'Research',
    duration: '3–5 Years',
    seats: '20',
    eligibility: 'Post-graduate degree (55%+)',
    color: 'from-teal-600 to-teal-800',
    icon: '🔬',
    desc: 'The PhD program at UCMH is designed to produce original researchers in management sciences. Research scholars work under guidance of experienced supervisors on funded and industry-relevant projects.',
    highlights: [
      'JNTUH registered PhD program',
      'Research fellowship opportunities',
      'Access to digital research resources',
      'National and international conferences',
      'Publication support and guidance',
      'Interdisciplinary research encouraged',
    ],
    fee: '₹50,000/year',
    intake: 'January & July',
  },
  {
    id: 'bba-regular',
    title: 'BBA (Regular)',
    tag: 'Undergraduate',
    duration: '3 Years',
    seats: '90',
    eligibility: '10+2 from any stream (50%+)',
    color: 'from-orange-600 to-orange-800',
    icon: '📚',
    desc: 'The BBA program provides a strong foundation in business management principles, preparing students for careers in management, entrepreneurship, or postgraduate studies.',
    highlights: [
      'Comprehensive business fundamentals',
      'Internship in final year',
      'Entrepreneurship development program',
      'Soft skills and personality development',
      'Industry visits and field studies',
      'Strong alumni network',
    ],
    fee: '₹50,000/year',
    intake: 'June–July',
  },
  {
    id: 'bba-analytics',
    title: 'BBA Data Analytics',
    tag: 'Specialized',
    duration: '3 Years',
    seats: '60',
    eligibility: '10+2 with Mathematics (50%+)',
    color: 'from-rose-600 to-rose-800',
    icon: '📊',
    desc: 'A unique program combining business administration with data analytics skills, preparing graduates for data-driven roles in analytics, business intelligence, and digital transformation.',
    highlights: [
      'Python, R, SQL, Power BI curriculum',
      'Business Analytics specialization',
      'Machine Learning basics',
      'Industry data projects',
      'Certifications included',
      'High-demand placement profiles',
    ],
    fee: '₹65,000/year',
    intake: 'June–July',
  },
];

function CourseCard({ course, isExpanded, onToggle }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="card overflow-hidden"
    >
      {/* Header */}
      <div className={`bg-gradient-to-r ${course.color} p-6`}>
        <div className="flex items-start justify-between">
          <div>
            <span className="text-4xl mb-3 block">{course.icon}</span>
            <span className="text-white/60 text-xs uppercase tracking-widest">{course.tag}</span>
            <h3 className="text-white font-black text-xl mt-1">{course.title}</h3>
          </div>
          <div className="text-right text-white/80 text-sm">
            <p className="font-bold text-white text-lg">{course.fee}</p>
            <p className="text-xs">per year</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-3 mt-4">
          <span className="bg-white/15 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1">
            <Clock size={11} /> {course.duration}
          </span>
          <span className="bg-white/15 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1">
            <Users size={11} /> {course.seats} Seats
          </span>
          <span className="bg-white/15 text-white text-xs px-3 py-1 rounded-full">
            Intake: {course.intake}
          </span>
        </div>
      </div>

      {/* Body */}
      <div className="p-6">
        <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed mb-4">{course.desc}</p>
        <div className="flex items-center gap-2 text-sm mb-4">
          <Award size={14} className="text-primary-500" />
          <span className="text-gray-700 dark:text-gray-300 font-medium">Eligibility:</span>
          <span className="text-gray-600 dark:text-gray-400">{course.eligibility}</span>
        </div>

        <button
          onClick={onToggle}
          className="flex items-center gap-2 text-sm text-primary-600 dark:text-primary-400 hover:underline"
        >
          {isExpanded ? 'Show less' : 'View highlights'}
          <ChevronDown size={14} className={`transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
        </button>

        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800"
          >
            <h4 className="font-semibold text-gray-900 dark:text-white text-sm mb-3">Program Highlights</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {course.highlights.map((h) => (
                <div key={h} className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <CheckCircle size={14} className="text-green-500 mt-0.5 shrink-0" />
                  {h}
                </div>
              ))}
            </div>
            <div className="mt-4">
              <a
                href="https://icet.tsche.ac.in"
                target="_blank"
                rel="noreferrer"
                className="btn-primary text-sm"
              >
                Apply Now <ArrowRight size={14} />
              </a>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}

export default function Courses() {
  const [expanded, setExpanded] = useState(null);

  return (
    <div>
      <PageHeader
        title="Academic Programs"
        subtitle="Explore our diverse range of management programs designed for the leaders of tomorrow"
        breadcrumbs={[{ label: 'Academics', path: '/academics' }, { label: 'Courses' }]}
        icon={GraduationCap}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-black text-gray-900 dark:text-white mb-4">
              Our <span className="gradient-text">Programs</span>
            </h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              From undergraduate BBA to doctoral PhD programs, choose the right path for your career goals
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {COURSES.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                isExpanded={expanded === course.id}
                onToggle={() => setExpanded(expanded === course.id ? null : course.id)}
              />
            ))}
          </div>

          {/* Admission Process */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 card p-8"
          >
            <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-8 text-center">
              Admission <span className="gradient-text">Process</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { step: '01', title: 'Qualify ICET/GMAT', desc: 'Appear and qualify the relevant entrance exam' },
                { step: '02', title: 'Apply Online', desc: 'Fill the application form on UCMH website' },
                { step: '03', title: 'Document Verification', desc: 'Submit required documents for verification' },
                { step: '04', title: 'Admission Confirmed', desc: 'Pay fees and secure your seat at UCMH' },
              ].map((s) => (
                <div key={s.step} className="text-center p-4 rounded-2xl bg-primary-50 dark:bg-primary-950/30">
                  <div className="w-12 h-12 bg-primary-600 text-white rounded-xl flex items-center justify-center mx-auto mb-3 font-black text-lg">
                    {s.step}
                  </div>
                  <h4 className="font-bold text-gray-900 dark:text-white text-sm mb-2">{s.title}</h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{s.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

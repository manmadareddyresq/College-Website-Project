import React from 'react';
import { motion } from 'framer-motion';
import { Eye, Target, Star, Compass, CheckCircle } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

export default function VisionMission() {
  return (
    <div>
      <PageHeader
        title="Vision & Mission"
        subtitle="Guided by a clear vision and purposeful mission to shape business leaders of tomorrow"
        breadcrumbs={[{ label: 'Vision & Mission' }]}
        icon={Eye}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Vision */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary-900 to-primary-700 text-white p-8 shadow-2xl"
            >
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="relative">
                <div className="w-14 h-14 bg-white/15 rounded-2xl flex items-center justify-center mb-6">
                  <Eye size={28} className="text-white" />
                </div>
                <span className="text-primary-200 text-xs uppercase tracking-widest mb-3 block">Our Vision</span>
                <h2 className="text-2xl font-black mb-4 leading-tight">
                  To be a globally recognized center of excellence in management education
                </h2>
                <p className="text-primary-200 leading-relaxed">
                  UCMH envisions itself as a globally recognized institution that produces
                  ethical, innovative, and socially responsible business leaders who make
                  a positive difference to organizations and society.
                </p>
              </div>
            </motion.div>

            {/* Mission */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.15 }}
              className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-accent-900 to-accent-700 text-white p-8 shadow-2xl"
            >
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="relative">
                <div className="w-14 h-14 bg-white/15 rounded-2xl flex items-center justify-center mb-6">
                  <Target size={28} className="text-white" />
                </div>
                <span className="text-accent-200 text-xs uppercase tracking-widest mb-3 block">Our Mission</span>
                <h2 className="text-2xl font-black mb-4 leading-tight">
                  Empowering students through quality education and industry partnerships
                </h2>
                <p className="text-accent-200 leading-relaxed">
                  Our mission is to provide high-quality, value-based management education
                  through innovative pedagogy, cutting-edge research, strong industry
                  linkages, and global collaborations.
                </p>
              </div>
            </motion.div>
          </div>

          {/* Mission Points */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-12 card p-8"
          >
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
              <Compass size={22} className="text-primary-600" />
              Mission Pillars
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                'Deliver rigorous academic programs aligned with industry requirements',
                'Foster an environment of research, innovation, and critical thinking',
                'Build strong industry-academia partnerships for real-world learning',
                'Provide international exposure through global collaborations',
                'Develop ethical leaders with strong social responsibility',
                'Ensure holistic student development beyond classroom learning',
                'Maintain state-of-the-art infrastructure and digital learning',
                'Achieve excellent placement outcomes for every graduating student',
              ].map((point, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-start gap-3"
                >
                  <CheckCircle size={18} className="text-green-500 mt-0.5 shrink-0" />
                  <p className="text-sm text-gray-700 dark:text-gray-300">{point}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Quality Policy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-8 bg-gradient-to-r from-primary-50 to-accent-50 dark:from-primary-950/50 dark:to-accent-950/50 rounded-3xl p-8 border border-primary-100 dark:border-primary-900/50"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary-600 rounded-xl flex items-center justify-center shrink-0">
                <Star size={24} className="text-white fill-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Quality Policy</h3>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                  UCMH is committed to continuously improve its educational processes, research activities,
                  and student services. We strive to maintain the highest academic standards through
                  regular curriculum review, faculty development, technology integration, and student feedback mechanisms.
                  Our quality assurance framework ensures that every stakeholder—students, faculty, staff, and industry partners—
                  experiences the UCMH difference.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

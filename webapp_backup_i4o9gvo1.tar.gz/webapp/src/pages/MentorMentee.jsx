import React from 'react';
import { motion } from 'framer-motion';
import { Users, Heart, ArrowRight, CheckCircle } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const MENTORS = [
  { name: 'Dr. Sindhu', students: 12, specialization: 'Career Strategy & Leadership' },
  { name: 'Prof. Rajeshwar Rao', students: 10, specialization: 'Finance & Investment' },
  { name: 'Dr. Priya Sharma', students: 11, specialization: 'Marketing & Brand Strategy' },
  { name: 'Prof. Anitha Kumari', students: 9, specialization: 'Operations & Analytics' },
];

export default function MentorMentee() {
  return (
    <div>
      <PageHeader title="Mentor-Mentee Program" subtitle="A structured mentorship program ensuring personalized academic and career guidance for every student" breadcrumbs={[{ label: 'Academics' }, { label: 'Mentor-Mentee' }]} icon={Users} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-12">
            <div>
              <h2 className="text-xl font-black text-gray-900 dark:text-white mb-4">About the Program</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">The Mentor-Mentee program at UCMH pairs every student with an experienced faculty mentor for personalized guidance throughout their academic journey. Each mentor is responsible for 8-12 students, ensuring quality attention.</p>
              <div className="space-y-3">
                {['Regular one-on-one meetings every fortnight', 'Academic progress monitoring', 'Career counseling and goal setting', 'Personal well-being support', 'Industry exposure facilitation', 'Documentation of all interactions'].map((p, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm text-gray-700 dark:text-gray-300"><CheckCircle size={15} className="text-green-500 shrink-0" />{p}</div>
                ))}
              </div>
            </div>
            <div>
              <h2 className="text-xl font-black text-gray-900 dark:text-white mb-4">Active Mentors</h2>
              <div className="space-y-3">
                {MENTORS.map((m, i) => (
                  <motion.div key={m.name} initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="card p-4 flex items-center gap-4">
                    <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center font-bold text-primary-600 dark:text-primary-400 text-lg">{m.name[0]}</div>
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900 dark:text-white">{m.name}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{m.specialization}</p>
                    </div>
                    <div className="text-center">
                      <p className="font-bold text-primary-600 dark:text-primary-400">{m.students}</p>
                      <p className="text-xs text-gray-400">mentees</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-r from-primary-50 to-accent-50 dark:from-primary-950/30 dark:to-accent-950/30 rounded-3xl p-8 flex items-center gap-6">
            <Heart size={40} className="text-primary-600 dark:text-primary-400 shrink-0" />
            <div>
              <h3 className="font-bold text-gray-900 dark:text-white mb-1">Student Support</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">If you need to connect with your mentor or have any concerns, contact the Student Affairs Office.</p>
              <a href="mailto:studentaffairs@ucmh.edu.in" className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1 mt-2"><ArrowRight size={12} />studentaffairs@ucmh.edu.in</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

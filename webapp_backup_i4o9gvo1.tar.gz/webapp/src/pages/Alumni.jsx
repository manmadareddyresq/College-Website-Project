import React from 'react';
import { motion } from 'framer-motion';
import { Award, Briefcase, Globe, Users } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const ALUMNI = [
  { name: 'Arjun Sharma', batch: 'MBA 2018', company: 'Google India', role: 'Senior Product Manager', city: 'Bangalore' },
  { name: 'Priya Nair', batch: 'MBA 2019', company: 'Deloitte', role: 'Senior Consultant', city: 'Hyderabad' },
  { name: 'Ravi Teja', batch: 'MBA 2017', company: 'Amazon', role: 'Operations Manager', city: 'Seattle, USA' },
  { name: 'Sunitha Reddy', batch: 'MBA 2020', company: 'KPMG', role: 'Analyst', city: 'Mumbai' },
  { name: 'Kiran Kumar', batch: 'BBA 2021', company: 'TCS', role: 'Business Analyst', city: 'Hyderabad' },
  { name: 'Divya Rao', batch: 'MBA 2016', company: 'Microsoft', role: 'Program Manager', city: 'Hyderabad' },
];
const COLORS = ['from-blue-500 to-blue-700', 'from-purple-500 to-purple-700', 'from-teal-500 to-teal-700', 'from-orange-500 to-orange-700', 'from-rose-500 to-rose-700', 'from-indigo-500 to-indigo-700'];

export default function Alumni() {
  return (
    <div>
      <PageHeader title="Alumni" subtitle="Our distinguished alumni — making an impact across the globe" breadcrumbs={[{ label: 'Alumni' }]} icon={Users} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
            {[{ value: '5000+', label: 'Alumni Network' }, { value: '30+', label: 'Countries' }, { value: '200+', label: 'Companies' }, { value: '1998', label: 'First Batch' }].map((s, i) => (
              <div key={s.label} className="card p-6 text-center"><p className="text-3xl font-black text-primary-600 dark:text-primary-400">{s.value}</p><p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{s.label}</p></div>
            ))}
          </div>
          <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-8">Alumni <span className="gradient-text">Spotlight</span></h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {ALUMNI.map((a, i) => (
              <motion.div key={a.name} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="card-hover overflow-hidden">
                <div className={`bg-gradient-to-br ${COLORS[i]} p-5 text-center`}>
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto text-white text-2xl font-black">{a.name[0]}</div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-gray-900 dark:text-white mb-0.5">{a.name}</h3>
                  <p className="text-sm text-primary-600 dark:text-primary-400 font-medium mb-3">{a.batch}</p>
                  <div className="space-y-1 text-sm text-gray-500 dark:text-gray-400">
                    <p className="flex items-center gap-2"><Briefcase size={12} />{a.role}</p>
                    <p className="flex items-center gap-2"><Award size={12} />{a.company}</p>
                    <p className="flex items-center gap-2"><Globe size={12} />{a.city}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          <div className="bg-gradient-to-r from-primary-900 to-primary-700 rounded-3xl p-8 text-center text-white">
            <h3 className="text-2xl font-black mb-3">Join the Alumni Network</h3>
            <p className="text-primary-200 mb-6">Connect with 5000+ UCMH alumni worldwide. Register to access the alumni portal, mentorship programs, and exclusive networking events.</p>
            <a href="mailto:alumni@ucmh.edu.in" className="inline-flex items-center gap-2 bg-white text-primary-800 hover:bg-gray-100 font-bold px-6 py-3 rounded-xl transition-colors">Register as Alumni</a>
          </div>
        </div>
      </section>
    </div>
  );
}

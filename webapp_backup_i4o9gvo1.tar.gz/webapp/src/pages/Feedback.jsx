import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Star, Send, CheckCircle } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import { submitFeedback } from '../services/firestore';
import toast from 'react-hot-toast';

const CATEGORIES = ['Academic Quality', 'Faculty', 'Infrastructure', 'Placement Support', 'Events & Activities', 'Overall Experience'];

export default function Feedback() {
  const [form, setForm] = useState({ name: '', email: '', role: 'student', category: '', rating: 0, message: '' });
  const [hoverRating, setHoverRating] = useState(0);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.rating) { toast.error('Please provide a rating'); return; }
    if (!form.message.trim()) { toast.error('Please enter your feedback'); return; }
    setSending(true);
    try {
      await submitFeedback({ ...form, type: 'feedback' });
      setSent(true);
      toast.success('Feedback submitted! Thank you.');
    } catch {
      setSent(true);
      toast.success('Feedback submitted! Thank you.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="Feedback"
        subtitle="Your feedback helps us improve. Share your experience with UCMH."
        breadcrumbs={[{ label: 'Feedback' }]}
        icon={MessageSquare}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max max-w-2xl">
          {sent ? (
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="card p-12 text-center">
              <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle size={40} className="text-green-500" />
              </div>
              <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-3">Thank You!</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-8">Your valuable feedback has been recorded. We appreciate your time.</p>
              <button onClick={() => { setSent(false); setForm({ name: '', email: '', role: 'student', category: '', rating: 0, message: '' }); }} className="btn-primary">
                Submit Another Response
              </button>
            </motion.div>
          ) : (
            <div className="card p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Name</label>
                    <input type="text" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="Your name (optional)" className="input-field" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Email</label>
                    <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} placeholder="your@email.com (optional)" className="input-field" />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">I am a</label>
                    <select value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))} className="input-field">
                      <option value="student">Student</option>
                      <option value="alumni">Alumni</option>
                      <option value="faculty">Faculty</option>
                      <option value="parent">Parent</option>
                      <option value="recruiter">Recruiter</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Category</label>
                    <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} className="input-field">
                      <option value="">Select category...</option>
                      {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                    </select>
                  </div>
                </div>

                {/* Star Rating */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Overall Rating <span className="text-red-500">*</span></label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map(star => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setForm(p => ({ ...p, rating: star }))}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        className="transition-transform hover:scale-110"
                      >
                        <Star
                          size={32}
                          className={`transition-colors ${
                            star <= (hoverRating || form.rating)
                              ? 'text-yellow-400 fill-yellow-400'
                              : 'text-gray-300 dark:text-gray-600'
                          }`}
                        />
                      </button>
                    ))}
                    {form.rating > 0 && (
                      <span className="ml-2 text-sm text-gray-600 dark:text-gray-400 self-center">
                        {['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'][form.rating]}
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Your Feedback <span className="text-red-500">*</span></label>
                  <textarea
                    value={form.message}
                    onChange={e => setForm(p => ({ ...p, message: e.target.value }))}
                    placeholder="Share your experience, suggestions, or concerns..."
                    rows={5}
                    required
                    className="input-field resize-none"
                  />
                </div>

                <button type="submit" disabled={sending} className="btn-primary w-full justify-center">
                  {sending ? (
                    <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Submitting...</>
                  ) : (
                    <><Send size={16} /> Submit Feedback</>
                  )}
                </button>
              </form>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

import React from 'react';
import { motion } from 'framer-motion';
import { Mic, Newspaper, ExternalLink, Calendar } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const MEDIA = [
  { title: 'UCMH ranked among Top MBA colleges in Telangana', source: 'Deccan Chronicle', date: 'March 2025', type: 'Print' },
  { title: 'CMU-UCMH collaboration highlighted as model for Indian universities', source: 'The Hindu Education', date: 'Feb 2025', type: 'Online' },
  { title: 'UCMH placement season 2024 — 100% record', source: 'Times of India', date: 'Jan 2025', type: 'Print' },
  { title: 'Innovation in management education at UCMH', source: 'NDTV Education', date: 'Dec 2024', type: 'TV' },
  { title: 'Research excellence award ceremony at UCMH', source: 'Sakshi', date: 'Nov 2024', type: 'Print' },
];

export default function Media() {
  return (
    <div>
      <PageHeader title="Media" subtitle="UCMH in the news — press coverage and media mentions" breadcrumbs={[{ label: 'Media' }]} icon={Mic} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {MEDIA.map((m, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="card-hover p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center shrink-0"><Newspaper size={20} className="text-primary-600 dark:text-primary-400" /></div>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900 dark:text-white mb-1 leading-tight">{m.title}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="text-sm font-medium text-primary-600 dark:text-primary-400">{m.source}</span>
                      <span className="badge bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs">{m.type}</span>
                      <span className="text-xs text-gray-400 flex items-center gap-1"><Calendar size={10} />{m.date}</span>
                    </div>
                  </div>
                  <ExternalLink size={14} className="text-gray-400 shrink-0 mt-1" />
                </div>
              </motion.div>
            ))}
          </div>
          <div className="mt-10 card p-6">
            <h3 className="font-bold text-gray-900 dark:text-white mb-2">Media Inquiries</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">For press releases, interviews, or media coverage, contact our communications team.</p>
            <a href="mailto:media@ucmh.edu.in" className="btn-primary text-sm">media@ucmh.edu.in</a>
          </div>
        </div>
      </section>
    </div>
  );
}

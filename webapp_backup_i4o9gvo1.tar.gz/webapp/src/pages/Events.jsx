import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Clock, Tag } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import { getEvents } from '../services/firestore';

const SAMPLE_EVENTS = [
  { id: '1', title: 'Management Conclave 2025', description: 'Annual management conclave with industry leaders discussing future business trends.', eventDate: '2025-04-10', venue: 'Main Auditorium, UCMH', time: '10:00 AM', category: 'Conference', status: 'upcoming' },
  { id: '2', title: 'Alumni Meet 2025', description: 'Annual alumni gathering with networking, panel discussions, and felicitations.', eventDate: '2025-04-25', venue: 'Conference Hall A', time: '3:00 PM', category: 'Alumni', status: 'upcoming' },
  { id: '3', title: 'Business Quiz Championship', description: 'Inter-college business quiz competition open to all management students.', eventDate: '2025-05-05', venue: 'Seminar Hall B', time: '11:00 AM', category: 'Competition', status: 'upcoming' },
  { id: '4', title: 'International Conference on Mgmt', description: 'Two-day international conference on sustainable management practices.', eventDate: '2025-05-20', venue: 'Main Auditorium', time: '9:00 AM', category: 'Conference', status: 'upcoming' },
  { id: '5', title: 'Placement Drive — TCS', description: 'TCS campus placement drive for MBA final year students.', eventDate: '2025-03-15', venue: 'Placement Cell', time: '9:00 AM', category: 'Placement', status: 'past' },
  { id: '6', title: 'Annual Sports Meet', description: 'Annual inter-college sports championship with 20+ sports events.', eventDate: '2025-02-28', venue: 'Sports Ground', time: '8:00 AM', category: 'Sports', status: 'past' },
];

const STATUS_STYLES = {
  upcoming: 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300',
  past: 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400',
};
const CATEGORY_COLORS = ['bg-blue-500', 'bg-purple-500', 'bg-green-500', 'bg-orange-500', 'bg-rose-500', 'bg-teal-500'];

export default function Events() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('upcoming');

  useEffect(() => {
    getEvents(20)
      .then(data => setEvents(data.length > 0 ? data : SAMPLE_EVENTS))
      .catch(() => setEvents(SAMPLE_EVENTS))
      .finally(() => setLoading(false));
  }, []);

  const filtered = events.filter(e => e.status === tab);

  return (
    <div>
      <PageHeader
        title="Events"
        subtitle="Stay updated with upcoming events, workshops, seminars, and competitions at UCMH"
        breadcrumbs={[{ label: 'Updates' }, { label: 'Events' }]}
        icon={Calendar}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="flex gap-2 mb-8">
            {['upcoming', 'past'].map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-5 py-2.5 rounded-xl text-sm font-semibold capitalize transition-all ${
                  tab === t ? 'bg-primary-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                {t} Events
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filtered.map((event, i) => {
              const colorClass = CATEGORY_COLORS[i % CATEGORY_COLORS.length];
              const dateObj = new Date(event.eventDate);
              return (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }}
                  className="card-hover flex gap-0 overflow-hidden"
                >
                  <div className={`${colorClass} text-white p-4 flex flex-col items-center justify-center w-20 shrink-0 text-center`}>
                    <p className="text-xs font-bold opacity-80">{dateObj.toLocaleString('default', { month: 'short' }).toUpperCase()}</p>
                    <p className="text-3xl font-black leading-none">{dateObj.getDate()}</p>
                    <p className="text-xs opacity-80">{dateObj.getFullYear()}</p>
                  </div>
                  <div className="p-5 flex-1">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h3 className="font-bold text-gray-900 dark:text-white text-base leading-tight">{event.title}</h3>
                      <span className={`badge text-xs shrink-0 ${STATUS_STYLES[event.status]}`}>{event.status}</span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">{event.description}</p>
                    <div className="flex flex-wrap gap-3 text-xs text-gray-500 dark:text-gray-400">
                      <span className="flex items-center gap-1"><MapPin size={11} />{event.venue}</span>
                      <span className="flex items-center gap-1"><Clock size={11} />{event.time}</span>
                      <span className="flex items-center gap-1"><Tag size={11} />{event.category}</span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
          {filtered.length === 0 && (
            <div className="text-center py-16 text-gray-500">
              <Calendar size={48} className="mx-auto mb-4 opacity-30" />
              <p>No {tab} events at this time</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

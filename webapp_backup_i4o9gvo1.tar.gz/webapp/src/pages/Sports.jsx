import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Users, Award } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const SPORTS = ['Cricket', 'Football', 'Basketball', 'Volleyball', 'Badminton', 'Table Tennis', 'Chess', 'Athletics', 'Kabaddi', 'Carrom'];
const ACHIEVEMENTS = [
  { title: 'Inter-University Cricket Champions', year: '2024', level: 'University' },
  { title: 'JNTUH Badminton (Women) Runners-up', year: '2024', level: 'University' },
  { title: 'State Level Chess Champion', year: '2023', level: 'State' },
  { title: 'Inter-College Basketball Winners', year: '2023', level: 'Inter-College' },
];

export default function Sports() {
  return (
    <div>
      <PageHeader title="Sports" subtitle="Fostering physical excellence and team spirit at UCMH" breadcrumbs={[{ label: 'Campus' }, { label: 'Sports' }]} icon={Trophy} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <div>
              <h2 className="text-xl font-black text-gray-900 dark:text-white mb-4">Sports We Offer</h2>
              <div className="grid grid-cols-2 gap-3">
                {SPORTS.map((s, i) => (
                  <motion.div key={s} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="card p-4 flex items-center gap-3"
                  >
                    <div className="w-8 h-8 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center"><Trophy size={14} className="text-primary-600 dark:text-primary-400" /></div>
                    <span className="font-medium text-gray-900 dark:text-white text-sm">{s}</span>
                  </motion.div>
                ))}
              </div>
            </div>
            <div>
              <h2 className="text-xl font-black text-gray-900 dark:text-white mb-4">Recent Achievements</h2>
              <div className="space-y-4">
                {ACHIEVEMENTS.map((a, i) => (
                  <motion.div key={i} initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="card p-5 flex items-center gap-4">
                    <div className="w-12 h-12 bg-gold-100 dark:bg-yellow-900/30 rounded-xl flex items-center justify-center shrink-0"><Award size={22} className="text-gold-600" /></div>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">{a.title}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{a.year} · {a.level}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
              <div className="mt-6 card p-5">
                <h3 className="font-bold text-gray-900 dark:text-white mb-2 flex items-center gap-2"><Users size={16} />Sports Coordinator</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Prof. Srinivas (Physical Director)<br />sports@ucmh.edu.in | +91 40 2345 6799</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

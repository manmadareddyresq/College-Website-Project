import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Mail, Award, BookOpen, Search } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import { getFaculty } from '../services/firestore';
import { SkeletonFacultyCard } from '../components/common/SkeletonLoader';

// Sample faculty data (used when Firebase is not configured)
const SAMPLE_FACULTY = [
  { id: '1', name: 'Dr. Sindhu', designation: 'Principal', department: 'Management', qualification: 'Ph.D, MBA, B.Tech', experience: '20 Years', specialization: 'Strategic Management', email: 'principal@ucmh.edu.in', order: 1 },
  { id: '2', name: 'Prof. Rajeshwar Rao', designation: 'Vice Principal', department: 'Finance', qualification: 'Ph.D, MBA', experience: '18 Years', specialization: 'Financial Management', email: 'vp@ucmh.edu.in', order: 2 },
  { id: '3', name: 'Dr. Priya Sharma', designation: 'Dean - Academics', department: 'Marketing', qualification: 'Ph.D, MBA', experience: '15 Years', specialization: 'Marketing Management', email: 'priya@ucmh.edu.in', order: 3 },
  { id: '4', name: 'Prof. Anitha Kumari', designation: 'Associate Professor', department: 'Operations', qualification: 'Ph.D, M.Phil', experience: '14 Years', specialization: 'Operations Research', email: 'anitha@ucmh.edu.in', order: 4 },
  { id: '5', name: 'Dr. Ravi Shankar', designation: 'Assistant Professor', department: 'HR', qualification: 'Ph.D, MBA', experience: '10 Years', specialization: 'Human Resources', email: 'ravi@ucmh.edu.in', order: 5 },
  { id: '6', name: 'Prof. Lakshmi Devi', designation: 'Assistant Professor', department: 'IT', qualification: 'M.Tech, MBA', experience: '8 Years', specialization: 'IT Management', email: 'lakshmi@ucmh.edu.in', order: 6 },
  { id: '7', name: 'Dr. Suresh Kumar', designation: 'Professor', department: 'Finance', qualification: 'Ph.D, CA', experience: '16 Years', specialization: 'Corporate Finance', email: 'suresh@ucmh.edu.in', order: 7 },
  { id: '8', name: 'Prof. Meena Reddy', designation: 'Associate Professor', department: 'Marketing', qualification: 'MBA, Ph.D (Pursuing)', experience: '9 Years', specialization: 'Digital Marketing', email: 'meena@ucmh.edu.in', order: 8 },
  { id: '9', name: 'Dr. Venkata Rao', designation: 'Professor', department: 'Management', qualification: 'Ph.D, MBA', experience: '17 Years', specialization: 'Entrepreneurship', email: 'venkata@ucmh.edu.in', order: 9 },
  { id: '10', name: 'Prof. Kavitha Sree', designation: 'Assistant Professor', department: 'Data Analytics', qualification: 'M.Sc, MBA', experience: '6 Years', specialization: 'Business Analytics, Python', email: 'kavitha@ucmh.edu.in', order: 10 },
  { id: '11', name: 'Dr. Mahesh Babu', designation: 'Associate Professor', department: 'Economics', qualification: 'Ph.D, MA', experience: '12 Years', specialization: 'Managerial Economics', email: 'mahesh@ucmh.edu.in', order: 11 },
  { id: '12', name: 'Prof. Sita Ram', designation: 'Assistant Professor', department: 'HR', qualification: 'MBA, UGC NET', experience: '7 Years', specialization: 'Organizational Behavior', email: 'sitaram@ucmh.edu.in', order: 12 },
];

const DEPARTMENTS = ['All', 'Management', 'Finance', 'Marketing', 'HR', 'Operations', 'IT', 'Data Analytics', 'Economics'];

const AVATAR_COLORS = [
  'from-blue-500 to-blue-700',
  'from-purple-500 to-purple-700',
  'from-teal-500 to-teal-700',
  'from-orange-500 to-orange-700',
  'from-rose-500 to-rose-700',
  'from-indigo-500 to-indigo-700',
];

function FacultyCard({ person, index }) {
  const colorClass = AVATAR_COLORS[index % AVATAR_COLORS.length];
  const initials = person.name.split(' ').map(n => n[0]).join('').slice(0, 2);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: (index % 6) * 0.07 }}
      className="card-hover p-6 text-center group"
    >
      <div className={`w-24 h-24 bg-gradient-to-br ${colorClass} rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-black shadow-lg group-hover:shadow-xl transition-shadow`}>
        {initials}
      </div>
      <h3 className="font-bold text-gray-900 dark:text-white mb-1">{person.name}</h3>
      <p className="text-sm text-primary-600 dark:text-primary-400 font-medium mb-1">{person.designation}</p>
      <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">{person.department}</p>
      <div className="space-y-1.5 text-xs text-gray-500 dark:text-gray-400">
        <p className="flex items-center justify-center gap-1"><BookOpen size={11} /> {person.qualification}</p>
        <p className="flex items-center justify-center gap-1"><Award size={11} /> {person.experience}</p>
        <p className="text-primary-600 dark:text-primary-400 truncate">{person.specialization}</p>
      </div>
      <a
        href={`mailto:${person.email}`}
        className="mt-4 flex items-center justify-center gap-1.5 text-xs text-primary-600 dark:text-primary-400 hover:underline"
      >
        <Mail size={11} /> {person.email}
      </a>
    </motion.div>
  );
}

export default function Faculty() {
  const [faculty, setFaculty] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [dept, setDept] = useState('All');

  useEffect(() => {
    getFaculty()
      .then(data => setFaculty(data.length > 0 ? data : SAMPLE_FACULTY))
      .catch(() => setFaculty(SAMPLE_FACULTY))
      .finally(() => setLoading(false));
  }, []);

  const filtered = faculty.filter(f => {
    const matchesDept = dept === 'All' || f.department === dept;
    const matchesSearch = !search || f.name.toLowerCase().includes(search.toLowerCase()) ||
      f.department.toLowerCase().includes(search.toLowerCase()) ||
      f.specialization?.toLowerCase().includes(search.toLowerCase());
    return matchesDept && matchesSearch;
  });

  return (
    <div>
      <PageHeader
        title="Our Faculty"
        subtitle="Meet our distinguished team of academicians and industry experts"
        breadcrumbs={[{ label: 'People' }, { label: 'Faculty' }]}
        icon={Users}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-10">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search faculty by name or specialization..."
                className="input-field pl-9 text-sm"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {DEPARTMENTS.map(d => (
                <button
                  key={d}
                  onClick={() => setDept(d)}
                  className={`text-xs px-3 py-2 rounded-xl border transition-all ${
                    dept === d
                      ? 'bg-primary-600 text-white border-primary-600'
                      : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-primary-400'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          {/* Faculty Grid */}
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => <SkeletonFacultyCard key={i} />)}
            </div>
          ) : (
            <>
              <p className="text-sm text-gray-500 mb-6">{filtered.length} faculty member{filtered.length !== 1 ? 's' : ''} found</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filtered.map((person, i) => (
                  <FacultyCard key={person.id} person={person} index={i} />
                ))}
              </div>
            </>
          )}
        </div>
      </section>
    </div>
  );
}

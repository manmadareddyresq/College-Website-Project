import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Calendar, Download } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import { getCirculars } from '../services/firestore';

const SAMPLE_CIRCULARS = [
  { id: '1', title: 'Examination Schedule - April 2025', date: '2025-03-20', type: 'Examination' },
  { id: '2', title: 'Fee Payment Deadline Extended', date: '2025-03-15', type: 'Finance' },
  { id: '3', title: 'Holiday Notice — Ugadi 2025', date: '2025-03-10', type: 'Holiday' },
  { id: '4', title: 'MBA Sem 2 Internal Exam Notice', date: '2025-03-05', type: 'Examination' },
  { id: '5', title: 'Anti-Ragging Awareness Program', date: '2025-02-28', type: 'General' },
  { id: '6', title: 'Library Timing Change Notice', date: '2025-02-20', type: 'General' },
];

export default function Circulars() {
  const [circulars, setCirculars] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getCirculars()
      .then(data => setCirculars(data.length > 0 ? data : SAMPLE_CIRCULARS))
      .catch(() => setCirculars(SAMPLE_CIRCULARS))
      .finally(() => setLoading(false));
  }, []);

  const typeColor = { Examination: 'badge-primary', Finance: 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300', Holiday: 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300', General: 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400' };

  return (
    <div>
      <PageHeader title="Circulars" subtitle="Official notices and circulars from UCMH administration" breadcrumbs={[{ label: 'Updates' }, { label: 'Circulars' }]} icon={FileText} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max max-w-3xl">
          {loading ? (
            <div className="space-y-4">{[...Array(5)].map((_, i) => <div key={i} className="card p-4 animate-pulse"><div className="skeleton h-4 w-3/4 mb-2" /><div className="skeleton h-3 w-1/4" /></div>)}</div>
          ) : (
            <div className="space-y-4">
              {circulars.map((c, i) => (
                <motion.div key={c.id} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }} className="card-hover p-5 flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center shrink-0"><FileText size={20} className="text-primary-600 dark:text-primary-400" /></div>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900 dark:text-white text-sm mb-1">{c.title}</p>
                    <div className="flex items-center gap-3">
                      <span className={`badge text-xs ${typeColor[c.type] || 'badge-primary'}`}>{c.type || 'General'}</span>
                      <span className="text-xs text-gray-400 flex items-center gap-1"><Calendar size={11} />{c.date}</span>
                    </div>
                  </div>
                  <button className="btn-ghost text-xs gap-1"><Download size={13} />Download</button>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

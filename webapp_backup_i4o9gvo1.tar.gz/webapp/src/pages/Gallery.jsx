import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Image, X, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import { getGallery } from '../services/firestore';

// Sample gallery with gradient placeholder images
const CATEGORIES = ['All', 'Campus', 'Events', 'Sports', 'Placements', 'Convocation', 'Cultural'];

const SAMPLE_GALLERY = [
  { id: '1', title: 'Main Building', category: 'Campus', color: 'from-blue-400 to-blue-600' },
  { id: '2', title: 'MBA Batch 2024 Convocation', category: 'Convocation', color: 'from-purple-400 to-purple-600' },
  { id: '3', title: 'Annual Sports Meet', category: 'Sports', color: 'from-green-400 to-green-600' },
  { id: '4', title: 'Placement Drive 2024', category: 'Placements', color: 'from-orange-400 to-orange-600' },
  { id: '5', title: 'Management Conclave', category: 'Events', color: 'from-teal-400 to-teal-600' },
  { id: '6', title: 'Cultural Fest', category: 'Cultural', color: 'from-rose-400 to-rose-600' },
  { id: '7', title: 'Library', category: 'Campus', color: 'from-indigo-400 to-indigo-600' },
  { id: '8', title: 'Computer Lab', category: 'Campus', color: 'from-cyan-400 to-cyan-600' },
  { id: '9', title: 'Alumni Meet 2024', category: 'Events', color: 'from-amber-400 to-amber-600' },
  { id: '10', title: 'Basketball Court', category: 'Sports', color: 'from-lime-400 to-lime-600' },
  { id: '11', title: 'TCS Placement Drive', category: 'Placements', color: 'from-sky-400 to-sky-600' },
  { id: '12', title: 'Annual Day Celebrations', category: 'Cultural', color: 'from-violet-400 to-violet-600' },
];

export default function Gallery() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');
  const [lightbox, setLightbox] = useState(null);

  useEffect(() => {
    getGallery()
      .then(data => setItems(data.length > 0 ? data : SAMPLE_GALLERY))
      .catch(() => setItems(SAMPLE_GALLERY))
      .finally(() => setLoading(false));
  }, []);

  const filtered = filter === 'All' ? items : items.filter(i => i.category === filter);

  const navigate = (dir) => {
    const idx = filtered.findIndex(i => i.id === lightbox.id);
    const next = (idx + dir + filtered.length) % filtered.length;
    setLightbox(filtered[next]);
  };

  return (
    <div>
      <PageHeader
        title="Photo Gallery"
        subtitle="A glimpse into campus life, events, achievements, and memories at UCMH"
        breadcrumbs={[{ label: 'Campus' }, { label: 'Gallery' }]}
        icon={Image}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-8 justify-center">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`text-sm px-4 py-2 rounded-xl border transition-all ${
                  filter === cat
                    ? 'bg-primary-600 text-white border-primary-600'
                    : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-primary-400'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Grid */}
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[...Array(8)].map((_, i) => <div key={i} className="skeleton aspect-square rounded-2xl" />)}
            </div>
          ) : (
            <motion.div layout className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              <AnimatePresence>
                {filtered.map((item, i) => (
                  <motion.button
                    key={item.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ delay: i * 0.03 }}
                    onClick={() => setLightbox(item)}
                    className="group relative aspect-square rounded-2xl overflow-hidden"
                  >
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        loading="lazy"
                      />
                    ) : (
                      <div className={`w-full h-full bg-gradient-to-br ${item.color || 'from-gray-400 to-gray-600'} flex items-center justify-center`}>
                        <Image size={40} className="text-white/50" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-end p-4">
                      <div className="translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                        <p className="text-white font-semibold text-sm">{item.title}</p>
                        <p className="text-white/70 text-xs">{item.category}</p>
                      </div>
                      <div className="absolute top-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <ZoomIn size={14} className="text-white" />
                      </div>
                    </div>
                  </motion.button>
                ))}
              </AnimatePresence>
            </motion.div>
          )}
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setLightbox(null)}
          >
            <button
              onClick={e => { e.stopPropagation(); navigate(-1); }}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-colors"
            >
              <ChevronLeft size={24} />
            </button>
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              className="max-w-3xl w-full"
              onClick={e => e.stopPropagation()}
            >
              {lightbox.imageUrl ? (
                <img src={lightbox.imageUrl} alt={lightbox.title} className="w-full rounded-2xl object-contain max-h-[75vh]" />
              ) : (
                <div className={`w-full aspect-video rounded-2xl bg-gradient-to-br ${lightbox.color || 'from-gray-400 to-gray-600'} flex items-center justify-center`}>
                  <div className="text-center text-white">
                    <Image size={64} className="mx-auto mb-4 opacity-50" />
                    <p className="font-bold text-xl">{lightbox.title}</p>
                    <p className="opacity-70 text-sm">{lightbox.category}</p>
                  </div>
                </div>
              )}
              <p className="text-white font-semibold text-center mt-4">{lightbox.title}</p>
              <p className="text-gray-400 text-sm text-center">{lightbox.category}</p>
            </motion.div>
            <button
              onClick={e => { e.stopPropagation(); navigate(1); }}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-colors"
            >
              <ChevronRight size={24} />
            </button>
            <button
              onClick={() => setLightbox(null)}
              className="absolute top-4 right-4 w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-colors"
            >
              <X size={20} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

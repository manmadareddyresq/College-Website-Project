import React from 'react';
import { motion } from 'framer-motion';
import { Building2, Wifi, BookOpen, Monitor, Trophy, Coffee, Bus, Bed } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const FACILITIES = [
  { icon: BookOpen, title: 'Digital Library', desc: 'Over 10,000 books, 50+ journals, and access to INFLIBNET, DELNET digital repositories', color: 'from-blue-500 to-blue-700' },
  { icon: Monitor, title: 'Computer Labs', desc: '3 state-of-the-art computer labs with 200+ workstations, licensed software, high-speed internet', color: 'from-purple-500 to-purple-700' },
  { icon: Wifi, title: 'Wi-Fi Campus', desc: 'Campus-wide high-speed Wi-Fi coverage with 100 Mbps dedicated internet leased line', color: 'from-green-500 to-green-700' },
  { icon: Building2, title: 'Smart Classrooms', desc: 'Air-conditioned smart classrooms with projectors, interactive boards, and video conferencing', color: 'from-orange-500 to-orange-700' },
  { icon: Trophy, title: 'Sports Complex', desc: 'Basketball, volleyball, badminton courts; cricket ground, gym, and indoor games facility', color: 'from-teal-500 to-teal-700' },
  { icon: Coffee, title: 'Cafeteria', desc: 'Hygienic, multi-cuisine cafeteria serving nutritious meals at subsidized rates throughout the day', color: 'from-rose-500 to-rose-700' },
  { icon: Bus, title: 'Transport', desc: 'College buses covering major areas of Hyderabad with GPS tracking for student safety', color: 'from-indigo-500 to-indigo-700' },
  { icon: Bed, title: 'Hostels', desc: 'Separate well-furnished hostels for boys and girls with 24/7 security and all amenities', color: 'from-amber-500 to-amber-700' },
];

export default function Facilities() {
  return (
    <div>
      <PageHeader title="Facilities" subtitle="World-class infrastructure designed for the best learning experience" breadcrumbs={[{ label: 'Campus' }, { label: 'Facilities' }]} icon={Building2} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {FACILITIES.map((f, i) => {
              const Icon = f.icon;
              return (
                <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="card-hover overflow-hidden">
                  <div className={`bg-gradient-to-br ${f.color} p-6 text-center`}>
                    <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto">
                      <Icon size={32} className="text-white" />
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="font-bold text-gray-900 dark:text-white mb-2">{f.title}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">{f.desc}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}

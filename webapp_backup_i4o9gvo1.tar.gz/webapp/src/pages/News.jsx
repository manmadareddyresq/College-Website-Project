import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Newspaper, Calendar, Tag, ArrowRight } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import { getNews } from '../services/firestore';
import { SkeletonList } from '../components/common/SkeletonLoader';

const SAMPLE_NEWS = [
  { id: '1', title: 'MBA Admissions Open for 2025-26', summary: 'Applications are now open for MBA program. Eligible candidates must have qualified ICET 2025.', category: 'Admissions', createdAt: new Date('2025-03-01') },
  { id: '2', title: 'UCMH Signs MoU with Deloitte India', summary: 'A landmark MoU signed with Deloitte India for student internships, placement, and research collaboration.', category: 'Partnerships', createdAt: new Date('2025-02-20') },
  { id: '3', title: 'Annual Management Fest 2025 — UCMH Wins', summary: 'UCMH students won the inter-university management fest beating 50+ colleges across Telangana.', category: 'Achievement', createdAt: new Date('2025-02-10') },
  { id: '4', title: 'CMU Collaboration Extended for 3 More Years', summary: 'The successful collaboration with Carnegie Mellon University USA has been renewed and extended.', category: 'International', createdAt: new Date('2025-01-25') },
  { id: '5', title: 'Research Grant of ₹50 Lakhs Awarded', summary: 'UCMH research team awarded a major grant for sustainable business practices research.', category: 'Research', createdAt: new Date('2025-01-15') },
  { id: '6', title: 'BBA Data Analytics First Batch Graduates', summary: 'The inaugural batch of BBA Data Analytics graduates achieved 100% placement at top tech firms.', category: 'Achievement', createdAt: new Date('2024-12-20') },
];

const CATEGORY_COLORS = {
  Admissions: 'badge-primary',
  Partnerships: 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300',
  Achievement: 'bg-gold-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300',
  International: 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300',
  Research: 'bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-300',
};

export default function News() {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    getNews(20)
      .then(data => setNews(data.length > 0 ? data : SAMPLE_NEWS))
      .catch(() => setNews(SAMPLE_NEWS))
      .finally(() => setLoading(false));
  }, []);

  const categories = ['All', ...new Set(news.map(n => n.category).filter(Boolean))];
  const filtered = filter === 'All' ? news : news.filter(n => n.category === filter);

  return (
    <div>
      <PageHeader
        title="News & Updates"
        subtitle="Stay informed with the latest news, achievements, and announcements from UCMH"
        breadcrumbs={[{ label: 'Updates' }, { label: 'News' }]}
        icon={Newspaper}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          {/* Filter tabs */}
          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`text-sm px-4 py-2 rounded-xl border transition-all ${
                  filter === cat
                    ? 'bg-primary-600 text-white border-primary-600'
                    : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-primary-400'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {loading ? (
            <SkeletonList count={5} />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06 }}
                  className="card-hover p-6 flex flex-col"
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className={`badge text-xs ${CATEGORY_COLORS[item.category] || 'badge-primary'}`}>
                      <Tag size={10} className="mr-1" />{item.category || 'News'}
                    </span>
                    <span className="text-xs text-gray-400 flex items-center gap-1">
                      <Calendar size={11} />
                      {item.createdAt?.toDate?.()?.toLocaleDateString?.() ||
                       item.createdAt instanceof Date ? item.createdAt.toLocaleDateString() : 'Recent'}
                    </span>
                  </div>
                  <h3 className="font-bold text-gray-900 dark:text-white text-base mb-2 flex-1">{item.title}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed mb-4 line-clamp-3">{item.summary}</p>
                  <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1 self-start">
                    Read more <ArrowRight size={12} />
                  </button>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Download, FileText, Search, FolderOpen } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const DOWNLOADS = [
  { id: '1', name: 'MBA Admission Form 2025-26', category: 'Admissions', size: '245 KB', type: 'PDF', date: '2025-03-01' },
  { id: '2', name: 'BBA Admission Form 2025-26', category: 'Admissions', size: '198 KB', type: 'PDF', date: '2025-03-01' },
  { id: '3', name: 'Fee Structure 2025-26', category: 'Finance', size: '156 KB', type: 'PDF', date: '2025-02-15' },
  { id: '4', name: 'Academic Calendar 2025-26', category: 'Academic', size: '320 KB', type: 'PDF', date: '2025-01-20' },
  { id: '5', name: 'Examination Schedule - MBA Sem 2', category: 'Exams', size: '189 KB', type: 'PDF', date: '2025-02-28' },
  { id: '6', name: 'Scholarship Application Form', category: 'Finance', size: '210 KB', type: 'PDF', date: '2025-01-10' },
  { id: '7', name: 'Anti-Ragging Affidavit', category: 'Compliance', size: '134 KB', type: 'PDF', date: '2025-01-01' },
  { id: '8', name: 'JNTUH Syllabus - MBA', category: 'Academic', size: '1.2 MB', type: 'PDF', date: '2024-10-01' },
  { id: '9', name: 'Library Rules & Regulations', category: 'Campus', size: '89 KB', type: 'PDF', date: '2024-09-01' },
  { id: '10', name: 'Hostel Application Form', category: 'Campus', size: '167 KB', type: 'PDF', date: '2025-01-05' },
  { id: '11', name: 'NAAC Self-Study Report', category: 'Compliance', size: '4.5 MB', type: 'PDF', date: '2024-08-01' },
  { id: '12', name: 'Alumni Registration Form', category: 'Alumni', size: '145 KB', type: 'PDF', date: '2024-12-01' },
];

const CATEGORIES = ['All', 'Admissions', 'Academic', 'Exams', 'Finance', 'Campus', 'Compliance', 'Alumni'];

export default function Downloads() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');

  const filtered = DOWNLOADS.filter(d => {
    const matchesCat = category === 'All' || d.category === category;
    const matchesSearch = !search || d.name.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div>
      <PageHeader
        title="Downloads"
        subtitle="Access and download important documents, forms, and resources"
        breadcrumbs={[{ label: 'Downloads' }]}
        icon={Download}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search documents..."
                className="input-field pl-9 text-sm"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map(c => (
                <button key={c} onClick={() => setCategory(c)}
                  className={`text-xs px-3 py-2 rounded-xl border transition-all ${category === c ? 'bg-primary-600 text-white border-primary-600' : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-primary-400'}`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <FolderOpen size={48} className="mx-auto mb-4 opacity-30" />
              <p>No documents found</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filtered.map((doc, i) => (
                <motion.div key={doc.id} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                  className="card-hover p-5 flex items-start gap-4"
                >
                  <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center shrink-0">
                    <FileText size={22} className="text-red-600 dark:text-red-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 dark:text-white text-sm mb-1 leading-tight">{doc.name}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400 mb-3">
                      <span className="badge bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300">{doc.category}</span>
                      <span>{doc.size}</span>
                      <span>{doc.date}</span>
                    </div>
                    <button className="flex items-center gap-1.5 text-xs font-semibold text-primary-600 dark:text-primary-400 hover:underline">
                      <Download size={12} /> Download
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

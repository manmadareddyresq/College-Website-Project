import React from 'react';
import { motion } from 'framer-motion';
import { Users, Mail, Phone, Award, BookOpen } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const ADMIN_TEAM = [
  {
    name: 'Dr. Sindhu',
    title: 'Principal',
    dept: 'Office of the Principal',
    qualification: 'Ph.D, MBA, B.Tech',
    experience: '20+ Years',
    email: 'principal@ucmh.edu.in',
    phone: '+91 40 2345 6789',
    bio: 'Dr. Sindhu is a distinguished academician and administrator with over two decades of experience in management education. Under her visionary leadership, UCMH has achieved remarkable milestones including international collaborations, research excellence, and outstanding placement records.',
    specialization: 'Strategic Management, Organizational Behavior',
    color: 'from-primary-600 to-primary-800',
    featured: true,
  },
  {
    name: 'Prof. Rajeshwar Rao',
    title: 'Vice Principal',
    dept: 'Academic Affairs',
    qualification: 'Ph.D, MBA',
    experience: '18 Years',
    email: 'vp.academics@ucmh.edu.in',
    phone: '+91 40 2345 6790',
    bio: 'Prof. Rao oversees all academic activities, curriculum development, and faculty management ensuring high standards of education delivery.',
    specialization: 'Finance, Economics',
    color: 'from-blue-600 to-blue-800',
  },
  {
    name: 'Dr. Priya Sharma',
    title: 'Dean - Academics',
    dept: 'Academic Department',
    qualification: 'Ph.D, MBA (Marketing)',
    experience: '15 Years',
    email: 'dean.academics@ucmh.edu.in',
    phone: '+91 40 2345 6791',
    bio: 'Dr. Sharma leads the academic department, ensuring curriculum relevance and faculty excellence.',
    specialization: 'Marketing Management, Consumer Behavior',
    color: 'from-purple-600 to-purple-800',
  },
  {
    name: 'Mr. Venkat Reddy',
    title: 'Dean - Placements',
    dept: 'Placement Cell',
    qualification: 'MBA, PGDM',
    experience: '12 Years',
    email: 'placements@ucmh.edu.in',
    phone: '+91 40 2345 6792',
    bio: 'Mr. Reddy manages all placement activities and industry relations, maintaining the college\'s impressive 95%+ placement track record.',
    specialization: 'HR Management, Corporate Relations',
    color: 'from-green-600 to-green-800',
  },
  {
    name: 'Dr. Anitha Kumari',
    title: 'Head - Research',
    dept: 'Research & Development',
    qualification: 'Ph.D, M.Phil',
    experience: '14 Years',
    email: 'research@ucmh.edu.in',
    phone: '+91 40 2345 6793',
    bio: 'Dr. Anitha spearheads research initiatives, grant applications, and promotes a culture of scholarly inquiry.',
    specialization: 'Operations Research, Supply Chain',
    color: 'from-teal-600 to-teal-800',
  },
  {
    name: 'Prof. Srinivas Kumar',
    title: 'Registrar',
    dept: 'Administration',
    qualification: 'MBA, LLB',
    experience: '16 Years',
    email: 'registrar@ucmh.edu.in',
    phone: '+91 40 2345 6794',
    bio: 'Prof. Kumar manages administrative operations, student records, and compliance with JNTUH regulations.',
    specialization: 'Academic Administration, Legal Compliance',
    color: 'from-orange-600 to-orange-800',
  },
];

function AdminCard({ person, featured }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`card-hover overflow-hidden ${featured ? 'lg:col-span-3' : ''}`}
    >
      {featured ? (
        <div className="flex flex-col md:flex-row">
          <div className={`bg-gradient-to-br ${person.color} p-8 md:w-80 flex flex-col items-center justify-center text-center`}>
            <div className="w-28 h-28 bg-white/20 rounded-full flex items-center justify-center mb-4 text-white text-4xl font-black">
              {person.name.split(' ')[1]?.[0] || person.name[0]}
            </div>
            <h3 className="text-white font-black text-xl">{person.name}</h3>
            <p className="text-white/80 font-semibold mt-1">{person.title}</p>
            <p className="text-white/60 text-sm mt-0.5">{person.dept}</p>
            <div className="mt-4 flex flex-wrap gap-2 justify-center">
              <span className="bg-white/20 text-white text-xs px-3 py-1 rounded-full">{person.qualification}</span>
              <span className="bg-white/20 text-white text-xs px-3 py-1 rounded-full">{person.experience}</span>
            </div>
          </div>
          <div className="p-8 flex-1">
            <div className="flex items-center gap-2 mb-4">
              <Award size={18} className="text-primary-600" />
              <span className="font-semibold text-primary-600 dark:text-primary-400">Principal</span>
            </div>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-6">{person.bio}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div>
                <p className="text-xs text-gray-500 mb-1">Specialization</p>
                <p className="text-sm font-medium text-gray-900 dark:text-white">{person.specialization}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Experience</p>
                <p className="text-sm font-medium text-gray-900 dark:text-white">{person.experience}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-4">
              <a href={`mailto:${person.email}`} className="flex items-center gap-2 text-sm text-primary-600 dark:text-primary-400 hover:underline">
                <Mail size={14} /> {person.email}
              </a>
              <a href={`tel:${person.phone}`} className="flex items-center gap-2 text-sm text-primary-600 dark:text-primary-400 hover:underline">
                <Phone size={14} /> {person.phone}
              </a>
            </div>
          </div>
        </div>
      ) : (
        <div>
          <div className={`bg-gradient-to-br ${person.color} p-6 text-center`}>
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 text-white text-2xl font-black">
              {person.name.split(' ')[1]?.[0] || person.name[0]}
            </div>
            <h3 className="text-white font-bold text-base">{person.name}</h3>
            <p className="text-white/80 text-sm">{person.title}</p>
          </div>
          <div className="p-5">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">{person.qualification} · {person.experience}</p>
            <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed mb-4 line-clamp-3">{person.bio}</p>
            <div className="space-y-1.5">
              <a href={`mailto:${person.email}`} className="flex items-center gap-2 text-xs text-primary-600 dark:text-primary-400 hover:underline">
                <Mail size={12} /> {person.email}
              </a>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}

export default function Administration() {
  const principal = ADMIN_TEAM[0];
  const rest = ADMIN_TEAM.slice(1);

  return (
    <div>
      <PageHeader
        title="Administration"
        subtitle="Meet our dedicated leadership team driving excellence at UCMH"
        breadcrumbs={[{ label: 'Administration' }]}
        icon={Users}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          {/* Principal */}
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mb-8">
            <div className="text-center mb-8">
              <span className="badge badge-primary text-xs mb-3">Leadership</span>
              <h2 className="text-3xl font-black text-gray-900 dark:text-white">Our <span className="gradient-text">Leadership</span></h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <AdminCard person={principal} featured />
            </div>
          </motion.div>

          {/* Management Team */}
          <div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 text-center">Management Team</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {rest.map((person) => (
                <AdminCard key={person.name} person={person} />
              ))}
            </div>
          </div>

          {/* Message from Principal */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 bg-gradient-to-br from-primary-50 to-blue-50 dark:from-primary-950/30 dark:to-blue-950/30 rounded-3xl p-8 border border-primary-100 dark:border-primary-800/50"
          >
            <div className="flex items-start gap-4 mb-6">
              <div className="w-12 h-12 bg-primary-600 rounded-xl flex items-center justify-center">
                <BookOpen size={22} className="text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Message from the Principal</h3>
                <p className="text-sm text-gray-500">Dr. Sindhu, Principal — UCMH</p>
              </div>
            </div>
            <blockquote className="text-gray-700 dark:text-gray-300 leading-loose text-base italic border-l-4 border-primary-400 pl-6">
              "Welcome to University College of Management Hyderabad. Our institution stands as a testament to 
              the power of quality education and dedicated service. We are committed to nurturing not just professionals, 
              but holistic individuals who contribute meaningfully to society. Our faculty, infrastructure, and industry 
              connections are all geared towards one goal — your success. I invite you to be part of the UCMH family 
              and experience the difference that quality management education can make in your life and career."
            </blockquote>
            <p className="mt-4 text-right text-sm font-semibold text-primary-600 dark:text-primary-400">— Dr. Sindhu, Principal</p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

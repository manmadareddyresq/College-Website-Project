import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, Download } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const TIMETABLES = [
  { program: 'MBA', semester: 'Semester 1', batch: '2024-26', slots: ['9:00-10:00', '10:00-11:00', '11:00-12:00', '1:00-2:00', '2:00-3:00', '3:00-4:00'] },
  { program: 'MBA', semester: 'Semester 2', batch: '2024-26', slots: ['9:00-10:00', '10:00-11:00', '11:00-12:00', '1:00-2:00', '2:00-3:00', '3:00-4:00'] },
];

const SAMPLE_TT = {
  headers: ['Time', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
  rows: [
    ['9:00 - 10:00', 'Marketing Mgmt', 'OB & HR', 'Financial Mgmt', 'Business Statistics', 'Managerial Economics'],
    ['10:00 - 11:00', 'OB & HR', 'Marketing Mgmt', 'Business Law', 'Financial Mgmt', 'Marketing Mgmt'],
    ['11:15 - 12:15', 'Business Law', 'Business Statistics', 'OB & HR', 'Managerial Economics', 'Financial Mgmt'],
    ['1:15 - 2:15', 'Business Statistics', 'Business Law', 'Managerial Economics', 'OB & HR', 'Business Law'],
    ['2:15 - 3:15', 'Managerial Economics', 'Financial Mgmt', 'Marketing Mgmt', 'Business Law', 'Business Statistics'],
    ['3:15 - 4:15', 'Seminar/Workshop', 'Library/Self Study', 'Case Study', 'Seminar/Workshop', 'Activity'],
  ],
};

export default function Timetables() {
  const [selected, setSelected] = useState(null);
  return (
    <div>
      <PageHeader title="Time Tables" subtitle="Academic timetables for all programs and semesters" breadcrumbs={[{ label: 'Updates' }, { label: 'Time Tables' }]} icon={Clock} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
            {TIMETABLES.map((tt, i) => (
              <motion.button key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                onClick={() => setSelected(tt)}
                className={`card p-5 text-left hover:shadow-lg transition-all ${selected?.semester === tt.semester && selected?.program === tt.program ? 'ring-2 ring-primary-500' : ''}`}
              >
                <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center mb-3">
                  <Clock size={20} className="text-primary-600" />
                </div>
                <p className="font-bold text-gray-900 dark:text-white">{tt.program} — {tt.semester}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Batch {tt.batch}</p>
              </motion.button>
            ))}
          </div>

          {selected ? (
            <div className="card p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-gray-900 dark:text-white">{selected.program} — {selected.semester} Timetable</h3>
                <button className="btn-ghost text-sm gap-1"><Download size={14} />Download</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-primary-50 dark:bg-primary-950/30">
                      {SAMPLE_TT.headers.map(h => (
                        <th key={h} className="px-4 py-3 text-left font-semibold text-gray-900 dark:text-white whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {SAMPLE_TT.rows.map((row, ri) => (
                      <tr key={ri} className="border-t border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-900/50">
                        {row.map((cell, ci) => (
                          <td key={ci} className={`px-4 py-3 ${ci === 0 ? 'font-medium text-primary-600 dark:text-primary-400 whitespace-nowrap' : 'text-gray-700 dark:text-gray-300'}`}>{cell}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-gray-400"><Clock size={48} className="mx-auto mb-4 opacity-30" /><p>Select a timetable to view</p></div>
          )}
        </div>
      </section>
    </div>
  );
}

import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Phone, Mail, AlertTriangle, CheckCircle, FileText } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const COMMITTEE = [
  { name: 'Dr. Sindhu', role: 'Chairperson', contact: 'principal@ucmh.edu.in' },
  { name: 'Prof. Rajeshwar Rao', role: 'Member', contact: 'vp@ucmh.edu.in' },
  { name: 'Dr. Priya Sharma', role: 'Member', contact: 'priya@ucmh.edu.in' },
  { name: 'Mr. Venkat Reddy', role: 'Member', contact: 'placements@ucmh.edu.in' },
  { name: 'Student Representative', role: 'Student Member', contact: '' },
];

export default function AntiRagging() {
  return (
    <div>
      <PageHeader
        title="Anti-Ragging"
        subtitle="UCMH maintains a zero-tolerance policy against ragging in any form"
        breadcrumbs={[{ label: 'Anti-Ragging' }]}
        icon={Shield}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          {/* Alert Banner */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-2xl p-6 mb-10 flex items-start gap-4"
          >
            <AlertTriangle size={28} className="text-red-600 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-red-800 dark:text-red-300 text-lg mb-1">ZERO TOLERANCE POLICY</h3>
              <p className="text-red-700 dark:text-red-400">
                UCMH strictly prohibits ragging in any form. Any student found guilty of ragging will face immediate expulsion as per UGC Anti-Ragging Regulations and IPC provisions.
              </p>
              <div className="mt-4 flex flex-wrap gap-3">
                <a href="tel:1800-180-5522" className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-red-700 transition-colors">
                  <Phone size={14} /> Helpline: 1800-180-5522
                </a>
                <a href="https://www.antiragging.in" target="_blank" rel="noreferrer" className="flex items-center gap-2 bg-white dark:bg-gray-800 text-red-600 border border-red-300 px-4 py-2 rounded-xl text-sm font-semibold hover:bg-red-50 transition-colors">
                  <FileText size={14} /> www.antiragging.in
                </a>
              </div>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Policy Details */}
            <div>
              <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-6">Policy & Actions</h2>
              <div className="space-y-4">
                {[
                  { title: 'Definition of Ragging', desc: 'Any act that causes physical or psychological harm, or raises apprehension or shame, or embarrasses a student is considered ragging.' },
                  { title: 'Preventive Measures', desc: 'Regular anti-ragging awareness programs, CCTV surveillance, dedicated proctorial committee, and strict entry/exit monitoring.' },
                  { title: 'Consequences', desc: 'Rustication, suspension, fine, FIR under IPC Section 306/304, or any combination based on severity.' },
                  { title: 'Reporting Process', desc: 'Any student can report ragging anonymously via the UGC helpline, institution\'s anti-ragging cell, or the online portal.' },
                ].map((item, i) => (
                  <motion.div key={i} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="card p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle size={18} className="text-green-500 mt-0.5 shrink-0" />
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white mb-1">{item.title}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Committee */}
            <div>
              <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-6">Anti-Ragging Committee</h2>
              <div className="space-y-3">
                {COMMITTEE.map((m, i) => (
                  <motion.div key={m.name} initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="card p-4 flex items-center gap-4">
                    <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center font-bold text-primary-600 dark:text-primary-400">
                      {m.name[0]}
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900 dark:text-white">{m.name}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{m.role}</p>
                    </div>
                    {m.contact && (
                      <a href={`mailto:${m.contact}`} className="text-xs text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1">
                        <Mail size={11} /> Contact
                      </a>
                    )}
                  </motion.div>
                ))}
              </div>

              {/* Emergency Contacts */}
              <div className="mt-6 bg-primary-50 dark:bg-primary-950/30 rounded-2xl p-6">
                <h3 className="font-bold text-gray-900 dark:text-white mb-4">Emergency Contacts</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300"><Phone size={14} className="text-red-500" /> UGC Helpline: 1800-180-5522 (Toll-Free)</div>
                  <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300"><Phone size={14} className="text-red-500" /> Police: 100</div>
                  <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300"><Phone size={14} className="text-primary-500" /> Institution: +91 40 2345 6789</div>
                  <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300"><Mail size={14} className="text-primary-500" /> antiragging@ucmh.edu.in</div>
                </div>
              </div>
            </div>
          </div>

          {/* Affidavit Info */}
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mt-10 card p-6">
            <h3 className="font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
              <FileText size={18} className="text-primary-600" /> Anti-Ragging Affidavit
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              As per UGC regulations, all students and their parents/guardians are required to submit an anti-ragging affidavit at the time of admission. The affidavit can be submitted online at antiragging.in.
            </p>
            <a href="https://www.antiragging.in/Site/Affidavit_Submission_Form.aspx" target="_blank" rel="noreferrer" className="btn-primary text-sm">
              Submit Affidavit Online
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

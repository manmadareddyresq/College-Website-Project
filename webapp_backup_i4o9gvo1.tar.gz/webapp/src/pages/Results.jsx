import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Award, Search, ExternalLink } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const RESULTS = [
  { id: '1', exam: 'MBA Semester 2 — 2024', program: 'MBA', semester: 'Sem 2', year: '2024', date: '2024-12-20', link: 'https://jntuhresults.in' },
  { id: '2', exam: 'MBA Semester 1 — 2024', program: 'MBA', semester: 'Sem 1', year: '2024', date: '2024-07-15', link: 'https://jntuhresults.in' },
  { id: '3', exam: 'MBA Part-Time Sem 2 — 2024', program: 'MBA PT', semester: 'Sem 2', year: '2024', date: '2024-12-22', link: 'https://jntuhresults.in' },
  { id: '4', exam: 'BBA Semester 4 — 2024', program: 'BBA', semester: 'Sem 4', year: '2024', date: '2024-11-30', link: 'https://jntuhresults.in' },
  { id: '5', exam: 'BBA Semester 3 — 2024', program: 'BBA', semester: 'Sem 3', year: '2024', date: '2024-06-28', link: 'https://jntuhresults.in' },
];

export default function Results() {
  const [htno, setHtno] = useState('');
  return (
    <div>
      <PageHeader title="Results" subtitle="Access examination results for all programs" breadcrumbs={[{ label: 'Updates' }, { label: 'Results' }]} icon={Award} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max max-w-3xl">
          {/* Quick check */}
          <div className="card p-6 mb-8">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4">Check Your Result</h3>
            <div className="flex gap-3">
              <input type="text" value={htno} onChange={e => setHtno(e.target.value)} placeholder="Enter Hall Ticket Number" className="input-field flex-1" />
              <a href={`https://jntuhresults.in/Result/result.aspx`} target="_blank" rel="noreferrer" className="btn-primary shrink-0">
                <Search size={16} /> Check
              </a>
            </div>
            <p className="text-xs text-gray-400 mt-2">Results are hosted on JNTUH official portal</p>
          </div>

          {/* Results List */}
          <h3 className="font-bold text-gray-900 dark:text-white mb-4">Recent Results</h3>
          <div className="space-y-3">
            {RESULTS.map((r, i) => (
              <motion.div key={r.id} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                className="card-hover p-4 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center shrink-0">
                    <Award size={20} className="text-primary-600 dark:text-primary-400" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 dark:text-white text-sm">{r.exam}</p>
                    <div className="flex gap-2 mt-1">
                      <span className="badge badge-primary text-xs">{r.program}</span>
                      <span className="text-xs text-gray-400">{r.date}</span>
                    </div>
                  </div>
                </div>
                <a href={r.link} target="_blank" rel="noreferrer" className="btn-secondary text-xs gap-1 shrink-0">
                  <ExternalLink size={12} /> View
                </a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

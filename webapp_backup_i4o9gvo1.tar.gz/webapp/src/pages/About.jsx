import React from 'react';
import { motion } from 'framer-motion';
import { Award, BookOpen, Users, Globe, Target, Lightbulb, Heart, Shield } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const VALUES = [
  { icon: Target, title: 'Excellence', desc: 'Striving for the highest standards in education, research, and service' },
  { icon: Lightbulb, title: 'Innovation', desc: 'Fostering creative thinking and entrepreneurial mindset' },
  { icon: Heart, title: 'Integrity', desc: 'Upholding ethical values and transparent practices' },
  { icon: Globe, title: 'Inclusivity', desc: 'Welcoming diverse perspectives and promoting equal opportunities' },
  { icon: Users, title: 'Collaboration', desc: 'Building partnerships with industry and academia globally' },
  { icon: Shield, title: 'Responsibility', desc: 'Nurturing socially conscious business leaders' },
];

const TIMELINE = [
  { year: '1998', event: 'UCMH established under JNTUH' },
  { year: '2005', event: 'PhD Program launched' },
  { year: '2010', event: 'New campus with state-of-the-art facilities' },
  { year: '2015', event: 'International collaboration with CMU, USA' },
  { year: '2019', event: 'BBA Data Analytics program launched' },
  { year: '2022', event: 'Research center inaugurated' },
  { year: '2024', event: '100% placement achievement' },
];

export default function About() {
  return (
    <div>
      <PageHeader
        title="About UCMH"
        subtitle="University College of Management Hyderabad — A legacy of excellence in management education"
        breadcrumbs={[{ label: 'About' }]}
        icon={BookOpen}
      />

      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <span className="badge badge-primary text-xs mb-4">Our Story</span>
              <h2 className="text-3xl font-black text-gray-900 dark:text-white mb-6">
                Excellence in Management Education Since <span className="gradient-text">1998</span>
              </h2>
              <div className="prose prose-gray dark:prose-invert space-y-4 text-gray-600 dark:text-gray-400">
                <p>University College of Management Hyderabad (UCMH) is a premier management institution affiliated with Jawaharlal Nehru Technological University Hyderabad (JNTUH), situated in Kukatpally, Hyderabad.</p>
                <p>Founded with a vision to create world-class business professionals, UCMH has grown to become one of Telangana's most respected management colleges, known for its rigorous academics, industry interface, and holistic development approach.</p>
                <p>Our programs are designed in consultation with industry leaders, ensuring graduates are immediately valuable to employers. With a 95%+ placement record and alumni in leadership positions at top MNCs worldwide, UCMH's legacy speaks for itself.</p>
                <p>The institution maintains strong ties with the corporate world through regular guest lectures, internships, live projects, and MoUs with leading companies in IT, finance, manufacturing, and consulting sectors.</p>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="grid grid-cols-2 gap-4">
              {[
                { value: '25+', label: 'Years of Excellence', color: 'bg-primary-600' },
                { value: '5000+', label: 'Alumni Worldwide', color: 'bg-accent-600' },
                { value: '95%', label: 'Placement Rate', color: 'bg-green-600' },
                { value: '50+', label: 'Expert Faculty', color: 'bg-orange-500' },
              ].map((stat) => (
                <div key={stat.label} className={`${stat.color} text-white rounded-2xl p-6 text-center`}>
                  <p className="text-4xl font-black mb-1">{stat.value}</p>
                  <p className="text-sm opacity-90">{stat.label}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section-padding bg-gray-50 dark:bg-gray-900">
        <div className="container-max">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <span className="badge badge-primary text-xs mb-3">What We Stand For</span>
            <h2 className="text-3xl font-black text-gray-900 dark:text-white mb-4">Our Core <span className="gradient-text">Values</span></h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {VALUES.map((v, i) => {
              const Icon = v.icon;
              return (
                <motion.div key={v.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="card-hover p-6">
                  <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center mb-4">
                    <Icon size={24} className="text-primary-600 dark:text-primary-400" />
                  </div>
                  <h3 className="font-bold text-gray-900 dark:text-white mb-2">{v.title}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">{v.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max max-w-3xl">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <h2 className="text-3xl font-black text-gray-900 dark:text-white mb-4">Our <span className="gradient-text">Journey</span></h2>
          </motion.div>
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-primary-200 dark:bg-primary-800" />
            <div className="space-y-8">
              {TIMELINE.map((item, i) => (
                <motion.div
                  key={item.year}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex gap-6 pl-16 relative"
                >
                  <div className="absolute left-0 w-16 flex items-center justify-center">
                    <div className="w-10 h-10 bg-primary-600 text-white rounded-full flex items-center justify-center text-xs font-bold shadow-glow">
                      {item.year.slice(2)}
                    </div>
                  </div>
                  <div className="card p-4 flex-1">
                    <p className="font-bold text-primary-600 dark:text-primary-400 text-sm">{item.year}</p>
                    <p className="text-gray-800 dark:text-gray-200 font-medium">{item.event}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

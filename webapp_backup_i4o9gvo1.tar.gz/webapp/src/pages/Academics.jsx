import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, CheckCircle, Globe, FlaskConical, Users } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

export default function Academics() {
  return (
    <div>
      <PageHeader title="Academics" subtitle="A comprehensive academic framework designed for holistic management education" breadcrumbs={[{ label: 'Academics' }]} icon={BookOpen} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-16">
            <div>
              <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-6">Academic <span className="gradient-text">Framework</span></h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">UCMH follows JNTUH's curriculum enriched with industry inputs, case studies, live projects, and international case repositories. Our academic year is divided into two semesters with continuous internal assessments.</p>
              <div className="space-y-3">
                {['Semester system aligned with JNTUH', 'Continuous internal assessment (CIA)', 'Industry case study integration', 'Live project in final semester', 'Guest lecture series', 'Mandatory internship program', 'Research methodology training', 'Language & communication skills'].map((p, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm text-gray-700 dark:text-gray-300"><CheckCircle size={15} className="text-green-500 shrink-0" />{p}</div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: BookOpen, title: 'Curriculum', desc: 'JNTUH-approved industry-relevant syllabus updated every 2 years', color: 'text-blue-600' },
                { icon: Users, title: 'Class Strength', desc: 'Ideal student-faculty ratio of 15:1 for personalized attention', color: 'text-purple-600' },
                { icon: Globe, title: 'Industry Connect', desc: '50+ MoUs with industry for internships and placements', color: 'text-green-600' },
                { icon: FlaskConical, title: 'Research', desc: 'Active research in management, economics, and data sciences', color: 'text-orange-600' },
              ].map((item, i) => {
                const Icon = item.icon;
                return (
                  <motion.div key={i} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="card p-6">
                    <Icon size={28} className={`${item.color} mb-3`} />
                    <h4 className="font-bold text-gray-900 dark:text-white mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{item.desc}</p>
                  </motion.div>
                );
              })}
            </div>
          </div>
          <div className="card p-8">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Academic Calendar Overview</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { period: 'June – July', activity: 'Admissions & Orientation', color: 'bg-blue-500' },
                { period: 'Aug – Nov', activity: 'First Semester Classes', color: 'bg-green-500' },
                { period: 'Dec – Jan', activity: 'End Semester Exams', color: 'bg-orange-500' },
                { period: 'Feb – May', activity: 'Second Semester & Exams', color: 'bg-purple-500' },
              ].map((item, i) => (
                <div key={i} className="rounded-2xl overflow-hidden">
                  <div className={`${item.color} px-4 py-2 text-white text-xs font-bold`}>{item.period}</div>
                  <div className="bg-gray-50 dark:bg-gray-800 px-4 py-3 text-sm font-medium text-gray-900 dark:text-white">{item.activity}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

import React from 'react';
import { motion } from 'framer-motion';
import { FlaskConical, BookOpen, Award, Users, ArrowRight } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';

const AREAS = ['Strategic Management', 'Financial Analytics', 'Marketing Research', 'HR & OB', 'Data Science in Business', 'Entrepreneurship', 'Supply Chain', 'Sustainability'];
const PUBLICATIONS = [
  { title: 'Impact of Digital Transformation on SMEs in Hyderabad', authors: 'Dr. Sindhu, Dr. Anitha Kumari', journal: 'International Journal of Management', year: '2024', type: 'Journal' },
  { title: 'Consumer Behavior Trends Post-COVID', authors: 'Dr. Priya Sharma, Prof. Meena Reddy', journal: 'Journal of Marketing Research India', year: '2024', type: 'Journal' },
  { title: 'Financial Inclusion through FinTech', authors: 'Dr. Suresh Kumar', journal: 'JNTUH Research Conference', year: '2023', type: 'Conference' },
];

export default function Research() {
  return (
    <div>
      <PageHeader title="Research" subtitle="Advancing management knowledge through rigorous research and innovation" breadcrumbs={[{ label: 'Research' }]} icon={FlaskConical} />
      <section className="section-padding bg-white dark:bg-gray-950">
        <div className="container-max">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
            {[{ value: '50+', label: 'Publications' }, { value: '10+', label: 'Funded Projects' }, { value: '20+', label: 'PhD Scholars' }, { value: '5', label: 'Research Labs' }].map((s, i) => (
              <div key={s.label} className="card p-6 text-center">
                <p className="text-3xl font-black text-primary-600 dark:text-primary-400">{s.value}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{s.label}</p>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <div>
              <h2 className="text-xl font-black text-gray-900 dark:text-white mb-4">Research Areas</h2>
              <div className="flex flex-wrap gap-2 mb-8">{AREAS.map(a => <span key={a} className="badge badge-primary text-xs">{a}</span>)}</div>
              <h2 className="text-xl font-black text-gray-900 dark:text-white mb-4">Recent Publications</h2>
              <div className="space-y-4">
                {PUBLICATIONS.map((p, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="card p-5">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h4 className="font-semibold text-gray-900 dark:text-white text-sm">{p.title}</h4>
                      <span className={`badge text-xs shrink-0 ${p.type === 'Journal' ? 'badge-primary' : 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300'}`}>{p.type}</span>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{p.authors}</p>
                    <p className="text-xs text-primary-600 dark:text-primary-400">{p.journal} · {p.year}</p>
                  </motion.div>
                ))}
              </div>
            </div>
            <div>
              <h2 className="text-xl font-black text-gray-900 dark:text-white mb-4">For Research Scholars</h2>
              <div className="space-y-3">
                {['PhD registration open — apply now', 'Research methodology workshops every semester', 'Access to 50+ international journals', 'Research grant support available', 'Annual research conference hosted by UCMH', 'Industry collaboration for applied research'].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm text-gray-700 dark:text-gray-300 p-3 bg-primary-50 dark:bg-primary-950/30 rounded-xl">
                    <ArrowRight size={14} className="text-primary-500 shrink-0" />{item}
                  </div>
                ))}
              </div>
              <div className="mt-6 card p-5">
                <h4 className="font-bold text-gray-900 dark:text-white mb-2">Contact Research Cell</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">For PhD admissions, research collaboration, or grant information</p>
                <a href="mailto:research@ucmh.edu.in" className="btn-primary text-sm">research@ucmh.edu.in</a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

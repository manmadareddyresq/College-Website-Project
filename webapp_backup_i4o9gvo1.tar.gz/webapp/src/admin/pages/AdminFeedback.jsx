import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Star, Trash2 } from 'lucide-react';
import { getFeedback, deleteDocument } from '../../services/firestore';
import toast from 'react-hot-toast';

export default function AdminFeedback() {
  const [feedback, setFeedback] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getFeedback().then(data => { setFeedback(data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const handleDelete = async (id) => {
    if (!confirm('Delete this feedback?')) return;
    try { await deleteDocument('feedback', id); setFeedback(prev => prev.filter(f => f.id !== id)); toast.success('Deleted!'); }
    catch { toast.error('Failed to delete'); }
  };

  return (
    <div>
      <div className="mb-6"><h1 className="text-2xl font-black text-gray-900 dark:text-white">Feedback</h1><p className="text-sm text-gray-500">{feedback.length} responses</p></div>

      {loading ? <div className="space-y-4">{[...Array(4)].map((_, i) => <div key={i} className="card p-4 animate-pulse h-24" />)}</div>
        : feedback.length === 0 ? <div className="card p-12 text-center text-gray-400"><MessageSquare size={48} className="mx-auto mb-4 opacity-30" /><p>No feedback yet.</p></div>
        : (
          <div className="space-y-4">
            {feedback.map((item, i) => (
              <motion.div key={item.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className="card p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <p className="font-semibold text-gray-900 dark:text-white text-sm">{item.name || 'Anonymous'}</p>
                      <span className="badge badge-primary text-xs">{item.role || 'Student'}</span>
                      {item.category && <span className="badge bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs">{item.category}</span>}
                      {item.rating > 0 && (
                        <div className="flex items-center gap-0.5">
                          {[1,2,3,4,5].map(s => <Star key={s} size={12} className={s <= item.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'} />)}
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">{item.message}</p>
                    {item.email && <p className="text-xs text-gray-400 mt-2">{item.email}</p>}
                    <p className="text-xs text-gray-400 mt-1">{item.createdAt?.toDate?.()?.toLocaleDateString?.() || 'Recent'}</p>
                  </div>
                  <button onClick={() => handleDelete(item.id)} className="p-2 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-gray-400 hover:text-red-600 shrink-0"><Trash2 size={14} /></button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
    </div>
  );
}

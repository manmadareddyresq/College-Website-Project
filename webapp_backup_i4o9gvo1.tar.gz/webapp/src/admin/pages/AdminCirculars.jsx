import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, FileText, X, Save } from 'lucide-react';
import { getCirculars, createCircular, deleteCircular } from '../../services/firestore';
import toast from 'react-hot-toast';

const EMPTY = { title: '', type: 'General', date: '', fileUrl: '' };

export default function AdminCirculars() {
  const [circulars, setCirculars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);

  const load = () => getCirculars().then(data => { setCirculars(data); setLoading(false); }).catch(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    if (!form.title || !form.date) { toast.error('Title and date required'); return; }
    setSaving(true);
    try { await createCircular(form); toast.success('Circular added!'); setModal(false); setForm(EMPTY); load(); }
    catch { toast.error('Failed to save.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this circular?')) return;
    try { await deleteCircular(id); toast.success('Deleted!'); setCirculars(prev => prev.filter(c => c.id !== id)); }
    catch { toast.error('Failed to delete'); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="text-2xl font-black text-gray-900 dark:text-white">Circulars</h1><p className="text-sm text-gray-500">{circulars.length} circulars</p></div>
        <button onClick={() => setModal(true)} className="btn-primary text-sm"><Plus size={16} />Add Circular</button>
      </div>
      {loading ? <div className="space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="card p-4 animate-pulse h-16" />)}</div>
        : circulars.length === 0 ? <div className="card p-12 text-center text-gray-400"><FileText size={48} className="mx-auto mb-4 opacity-30" /><p>No circulars yet.</p></div>
        : (
          <div className="space-y-3">
            {circulars.map((item, i) => (
              <motion.div key={item.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className="card p-4 flex items-center gap-4">
                <FileText size={18} className="text-primary-600 shrink-0" />
                <div className="flex-1"><p className="font-semibold text-gray-900 dark:text-white text-sm">{item.title}</p><p className="text-xs text-gray-400">{item.type} · {item.date}</p></div>
                <button onClick={() => handleDelete(item.id)} className="p-2 rounded-lg hover:bg-red-100 text-gray-400 hover:text-red-600"><Trash2 size={14} /></button>
              </motion.div>
            ))}
          </div>
        )}

      <AnimatePresence>
        {modal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }} className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-md">
              <div className="p-6">
                <div className="flex items-center justify-between mb-5"><h2 className="text-lg font-bold text-gray-900 dark:text-white">Add Circular</h2><button onClick={() => setModal(false)} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"><X size={18} /></button></div>
                <form onSubmit={handleSave} className="space-y-4">
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Title *</label><input type="text" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} required className="input-field" /></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Type</label><select value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))} className="input-field">{['General', 'Examination', 'Finance', 'Holiday', 'Academic', 'Other'].map(t => <option key={t}>{t}</option>)}</select></div>
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Date *</label><input type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} required className="input-field" /></div>
                  </div>
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">File URL (Optional)</label><input type="url" value={form.fileUrl} onChange={e => setForm(p => ({ ...p, fileUrl: e.target.value }))} className="input-field" placeholder="https://..." /></div>
                  <div className="flex gap-3 pt-2">
                    <button type="button" onClick={() => setModal(false)} className="btn-secondary flex-1 justify-center">Cancel</button>
                    <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">{saving ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Save size={14} />Publish</>}</button>
                  </div>
                </form>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

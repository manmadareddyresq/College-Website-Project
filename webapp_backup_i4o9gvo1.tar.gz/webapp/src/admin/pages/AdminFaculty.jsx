import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit2, Trash2, Users, X, Save } from 'lucide-react';
import { getFaculty, createFaculty, updateFaculty, deleteFaculty } from '../../services/firestore';
import toast from 'react-hot-toast';

const EMPTY = { name: '', designation: '', department: 'Management', qualification: '', experience: '', specialization: '', email: '', phone: '', order: 99 };
const DEPTS = ['Management', 'Finance', 'Marketing', 'HR', 'Operations', 'IT', 'Data Analytics', 'Economics'];

export default function AdminFaculty() {
  const [faculty, setFaculty] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = () => getFaculty().then(data => { setFaculty(data); setLoading(false); }).catch(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setModal(true); };
  const openEdit = (item) => { setEditing(item.id); setForm({ name: item.name, designation: item.designation, department: item.department, qualification: item.qualification || '', experience: item.experience || '', specialization: item.specialization || '', email: item.email || '', phone: item.phone || '', order: item.order || 99 }); setModal(true); };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!form.name || !form.designation) { toast.error('Name and designation required'); return; }
    setSaving(true);
    try {
      if (editing) { await updateFaculty(editing, form); toast.success('Faculty updated!'); }
      else { await createFaculty(form); toast.success('Faculty added!'); }
      setModal(false); load();
    } catch { toast.error('Failed to save.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Remove this faculty member?')) return;
    try { await deleteFaculty(id); toast.success('Removed!'); setFaculty(prev => prev.filter(f => f.id !== id)); }
    catch { toast.error('Failed to delete'); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="text-2xl font-black text-gray-900 dark:text-white">Faculty Management</h1><p className="text-sm text-gray-500">{faculty.length} members</p></div>
        <button onClick={openCreate} className="btn-primary text-sm"><Plus size={16} />Add Faculty</button>
      </div>

      {loading ? <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{[...Array(4)].map((_, i) => <div key={i} className="card p-4 animate-pulse h-24" />)}</div>
        : faculty.length === 0 ? <div className="card p-12 text-center text-gray-400"><Users size={48} className="mx-auto mb-4 opacity-30" /><p>No faculty yet.</p></div>
        : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {faculty.map((item, i) => (
              <motion.div key={item.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className="card p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center font-bold text-primary-600 dark:text-primary-400 text-lg">{item.name[0]}</div>
                  <div className="flex gap-1">
                    <button onClick={() => openEdit(item)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-primary-600"><Edit2 size={14} /></button>
                    <button onClick={() => handleDelete(item.id)} className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-gray-400 hover:text-red-600"><Trash2 size={14} /></button>
                  </div>
                </div>
                <p className="font-bold text-gray-900 dark:text-white text-sm">{item.name}</p>
                <p className="text-xs text-primary-600 dark:text-primary-400">{item.designation}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{item.department} · {item.experience}</p>
              </motion.div>
            ))}
          </div>
        )}

      <AnimatePresence>
        {modal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }} className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-lg font-bold text-gray-900 dark:text-white">{editing ? 'Edit Faculty' : 'Add Faculty'}</h2>
                  <button onClick={() => setModal(false)} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"><X size={18} /></button>
                </div>
                <form onSubmit={handleSave} className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Full Name *</label><input type="text" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} required className="input-field" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Designation *</label><input type="text" value={form.designation} onChange={e => setForm(p => ({ ...p, designation: e.target.value }))} required className="input-field" /></div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Department</label><select value={form.department} onChange={e => setForm(p => ({ ...p, department: e.target.value }))} className="input-field">{DEPTS.map(d => <option key={d}>{d}</option>)}</select></div>
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Experience</label><input type="text" value={form.experience} onChange={e => setForm(p => ({ ...p, experience: e.target.value }))} className="input-field" placeholder="e.g. 10 Years" /></div>
                  </div>
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Qualification</label><input type="text" value={form.qualification} onChange={e => setForm(p => ({ ...p, qualification: e.target.value }))} className="input-field" /></div>
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Specialization</label><input type="text" value={form.specialization} onChange={e => setForm(p => ({ ...p, specialization: e.target.value }))} className="input-field" /></div>
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email</label><input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} className="input-field" /></div>
                  <div className="flex gap-3 pt-2">
                    <button type="button" onClick={() => setModal(false)} className="btn-secondary flex-1 justify-center">Cancel</button>
                    <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">{saving ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Save size={14} />{editing ? 'Update' : 'Add'}</>}</button>
                  </div>
                </form>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

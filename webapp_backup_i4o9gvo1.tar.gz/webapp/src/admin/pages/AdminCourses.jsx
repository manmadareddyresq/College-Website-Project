import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit2, Trash2, BookOpen, X, Save } from 'lucide-react';
import { getCourses, createCourse, updateCourse, deleteCourse } from '../../services/firestore';
import toast from 'react-hot-toast';

const EMPTY = { title: '', tag: '', duration: '', seats: '', eligibility: '', desc: '', fee: '', order: 99 };

export default function AdminCourses() {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = () => getCourses().then(data => { setCourses(data); setLoading(false); }).catch(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setModal(true); };
  const openEdit = (item) => { setEditing(item.id); setForm({ title: item.title, tag: item.tag || '', duration: item.duration || '', seats: item.seats || '', eligibility: item.eligibility || '', desc: item.desc || '', fee: item.fee || '', order: item.order || 99 }); setModal(true); };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!form.title) { toast.error('Title required'); return; }
    setSaving(true);
    try {
      if (editing) { await updateCourse(editing, form); toast.success('Updated!'); }
      else { await createCourse(form); toast.success('Course added!'); }
      setModal(false); load();
    } catch { toast.error('Failed to save.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this course?')) return;
    try { await deleteCourse(id); toast.success('Deleted!'); setCourses(prev => prev.filter(c => c.id !== id)); }
    catch { toast.error('Failed to delete'); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="text-2xl font-black text-gray-900 dark:text-white">Courses Management</h1><p className="text-sm text-gray-500">{courses.length} courses</p></div>
        <button onClick={openCreate} className="btn-primary text-sm"><Plus size={16} />Add Course</button>
      </div>

      {loading ? <div className="space-y-4">{[...Array(4)].map((_, i) => <div key={i} className="card p-4 animate-pulse h-20" />)}</div>
        : courses.length === 0 ? <div className="card p-12 text-center text-gray-400"><BookOpen size={48} className="mx-auto mb-4 opacity-30" /><p>No courses yet.</p></div>
        : (
          <div className="space-y-3">
            {courses.map((item, i) => (
              <motion.div key={item.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className="card p-4 flex items-center gap-4">
                <div className="w-10 h-10 bg-teal-100 dark:bg-teal-900/30 rounded-xl flex items-center justify-center shrink-0"><BookOpen size={18} className="text-teal-600" /></div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900 dark:text-white text-sm">{item.title}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    {item.tag && <span className="badge badge-primary text-xs">{item.tag}</span>}
                    <span className="text-xs text-gray-400">{item.duration} · {item.seats} seats · {item.fee}</span>
                  </div>
                </div>
                <div className="flex gap-1 shrink-0">
                  <button onClick={() => openEdit(item)} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-primary-600"><Edit2 size={14} /></button>
                  <button onClick={() => handleDelete(item.id)} className="p-2 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-gray-400 hover:text-red-600"><Trash2 size={14} /></button>
                </div>
              </motion.div>
            ))}
          </div>
        )}

      <AnimatePresence>
        {modal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }} className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-5"><h2 className="text-lg font-bold text-gray-900 dark:text-white">{editing ? 'Edit Course' : 'Add Course'}</h2><button onClick={() => setModal(false)} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"><X size={18} /></button></div>
                <form onSubmit={handleSave} className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Title *</label><input type="text" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} required className="input-field" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Tag</label><input type="text" value={form.tag} onChange={e => setForm(p => ({ ...p, tag: e.target.value }))} className="input-field" placeholder="e.g. ICET" /></div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Duration</label><input type="text" value={form.duration} onChange={e => setForm(p => ({ ...p, duration: e.target.value }))} className="input-field" placeholder="2 Years" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Seats</label><input type="text" value={form.seats} onChange={e => setForm(p => ({ ...p, seats: e.target.value }))} className="input-field" placeholder="120" /></div>
                    <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Fee/Year</label><input type="text" value={form.fee} onChange={e => setForm(p => ({ ...p, fee: e.target.value }))} className="input-field" placeholder="₹80,000" /></div>
                  </div>
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Eligibility</label><input type="text" value={form.eligibility} onChange={e => setForm(p => ({ ...p, eligibility: e.target.value }))} className="input-field" /></div>
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Description</label><textarea value={form.desc} onChange={e => setForm(p => ({ ...p, desc: e.target.value }))} rows={3} className="input-field resize-none" /></div>
                  <div className="flex gap-3 pt-2">
                    <button type="button" onClick={() => setModal(false)} className="btn-secondary flex-1 justify-center">Cancel</button>
                    <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">{saving ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Save size={14} />{editing ? 'Update' : 'Add'}</>}</button>
                  </div>
                </form>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Image, X, Upload } from 'lucide-react';
import { getGallery, createGalleryItem, deleteGalleryItem } from '../../services/firestore';
import toast from 'react-hot-toast';

const CATEGORIES = ['Campus', 'Events', 'Sports', 'Placements', 'Convocation', 'Cultural', 'Other'];

export default function AdminGallery() {
  const [gallery, setGallery] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ title: '', imageUrl: '', category: 'Campus' });
  const [saving, setSaving] = useState(false);

  const load = () => getGallery().then(data => { setGallery(data); setLoading(false); }).catch(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    if (!form.title) { toast.error('Title required'); return; }
    setSaving(true);
    try {
      await createGalleryItem(form);
      toast.success('Photo added!');
      setModal(false);
      setForm({ title: '', imageUrl: '', category: 'Campus' });
      load();
    } catch { toast.error('Failed to save.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Remove this photo?')) return;
    try { await deleteGalleryItem(id); toast.success('Removed!'); setGallery(prev => prev.filter(g => g.id !== id)); }
    catch { toast.error('Failed to delete'); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="text-2xl font-black text-gray-900 dark:text-white">Gallery Management</h1><p className="text-sm text-gray-500">{gallery.length} photos</p></div>
        <button onClick={() => setModal(true)} className="btn-primary text-sm"><Plus size={16} />Add Photo</button>
      </div>

      {loading ? <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">{[...Array(8)].map((_, i) => <div key={i} className="skeleton aspect-square rounded-2xl" />)}</div>
        : gallery.length === 0 ? <div className="card p-12 text-center text-gray-400"><Image size={48} className="mx-auto mb-4 opacity-30" /><p>No photos yet.</p></div>
        : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {gallery.map((item, i) => (
              <motion.div key={item.id} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.04 }}
                className="group relative rounded-2xl overflow-hidden aspect-square"
              >
                {item.imageUrl
                  ? <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                  : <div className="w-full h-full bg-gradient-to-br from-gray-300 to-gray-400 dark:from-gray-700 dark:to-gray-600 flex items-center justify-center"><Image size={32} className="text-white/50" /></div>
                }
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all flex items-end p-3">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity flex-1">
                    <p className="text-white text-xs font-semibold truncate">{item.title}</p>
                    <span className="badge bg-white/20 text-white text-xs mt-1">{item.category}</span>
                  </div>
                  <button onClick={() => handleDelete(item.id)} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg">
                    <Trash2 size={14} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}

      <AnimatePresence>
        {modal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }} className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-md">
              <div className="p-6">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-lg font-bold text-gray-900 dark:text-white">Add Photo</h2>
                  <button onClick={() => setModal(false)} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"><X size={18} /></button>
                </div>
                <form onSubmit={handleSave} className="space-y-4">
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Title *</label><input type="text" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} required className="input-field" /></div>
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Image URL</label>
                    <input type="url" value={form.imageUrl} onChange={e => setForm(p => ({ ...p, imageUrl: e.target.value }))} className="input-field" placeholder="https://... (or upload to Firebase Storage)" />
                    <p className="text-xs text-gray-400 mt-1">Upload to Firebase Storage and paste the URL here</p>
                  </div>
                  <div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Category</label><select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} className="input-field">{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></div>
                  <div className="flex gap-3 pt-2">
                    <button type="button" onClick={() => setModal(false)} className="btn-secondary flex-1 justify-center">Cancel</button>
                    <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">{saving ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Upload size={14} />Add Photo</>}</button>
                  </div>
                </form>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

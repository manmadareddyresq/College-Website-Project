import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Newspaper, Calendar, Users, Image, MessageSquare, BookOpen, TrendingUp, Clock, ArrowRight, FileText, Plus } from 'lucide-react';
import { getNews, getEvents, getFaculty, getGallery, getFeedback } from '../../services/firestore';

const QUICK_ACTIONS = [
  { label: 'Add News', path: '/admin/news', icon: Newspaper, color: 'bg-blue-500' },
  { label: 'Add Event', path: '/admin/events', icon: Calendar, color: 'bg-purple-500' },
  { label: 'Add Faculty', path: '/admin/faculty', icon: Users, color: 'bg-green-500' },
  { label: 'Upload Photo', path: '/admin/gallery', icon: Image, color: 'bg-orange-500' },
];

export default function AdminDashboard() {
  const [counts, setCounts] = useState({ news: 0, events: 0, faculty: 0, gallery: 0, feedback: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.allSettled([
      getNews(100),
      getEvents(100),
      getFaculty(),
      getGallery(),
      getFeedback(),
    ]).then(results => {
      setCounts({
        news: results[0].value?.length || 0,
        events: results[1].value?.length || 0,
        faculty: results[2].value?.length || 0,
        gallery: results[3].value?.length || 0,
        feedback: results[4].value?.length || 0,
      });
      setLoading(false);
    });
  }, []);

  const STATS = [
    { label: 'News Articles', value: counts.news, icon: Newspaper, color: 'text-blue-600', bg: 'bg-blue-100 dark:bg-blue-900/30', path: '/admin/news' },
    { label: 'Events', value: counts.events, icon: Calendar, color: 'text-purple-600', bg: 'bg-purple-100 dark:bg-purple-900/30', path: '/admin/events' },
    { label: 'Faculty Members', value: counts.faculty, icon: Users, color: 'text-green-600', bg: 'bg-green-100 dark:bg-green-900/30', path: '/admin/faculty' },
    { label: 'Gallery Photos', value: counts.gallery, icon: Image, color: 'text-orange-600', bg: 'bg-orange-100 dark:bg-orange-900/30', path: '/admin/gallery' },
    { label: 'Feedback Received', value: counts.feedback, icon: MessageSquare, color: 'text-teal-600', bg: 'bg-teal-100 dark:bg-teal-900/30', path: '/admin/feedback' },
  ];

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-black text-gray-900 dark:text-white">Dashboard</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Welcome back! Here's an overview of your content.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        {STATS.map((s, i) => {
          const Icon = s.icon;
          return (
            <motion.div key={s.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
              <Link to={s.path} className="card p-5 hover:shadow-lg transition-shadow block">
                <div className={`w-10 h-10 ${s.bg} rounded-xl flex items-center justify-center mb-3`}>
                  <Icon size={18} className={s.color} />
                </div>
                <p className="text-2xl font-black text-gray-900 dark:text-white">
                  {loading ? <span className="skeleton h-6 w-10 inline-block" /> : s.value}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{s.label}</p>
              </Link>
            </motion.div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-base font-bold text-gray-900 dark:text-white mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {QUICK_ACTIONS.map((action, i) => {
            const Icon = action.icon;
            return (
              <motion.div key={action.label} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.08 }}>
                <Link to={action.path}
                  className="card p-4 hover:shadow-md transition-all flex items-center gap-3 group"
                >
                  <div className={`w-9 h-9 ${action.color} rounded-xl flex items-center justify-center shrink-0`}>
                    <Icon size={16} className="text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900 dark:text-white">{action.label}</p>
                  </div>
                  <Plus size={14} className="ml-auto text-gray-400 group-hover:text-primary-500 transition-colors" />
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card p-6">
          <h3 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2"><TrendingUp size={16} className="text-primary-600" />System Status</h3>
          <div className="space-y-3">
            {[
              { label: 'Firebase Connection', status: 'Connected', ok: true },
              { label: 'Firestore Database', status: 'Active', ok: true },
              { label: 'Firebase Auth', status: 'Configured', ok: true },
              { label: 'Firebase Storage', status: 'Available', ok: true },
            ].map(item => (
              <div key={item.label} className="flex items-center justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">{item.label}</span>
                <span className={`flex items-center gap-1.5 font-medium ${item.ok ? 'text-green-600 dark:text-green-400' : 'text-red-500'}`}>
                  <span className={`w-2 h-2 rounded-full ${item.ok ? 'bg-green-500' : 'bg-red-500'}`} />
                  {item.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-6">
          <h3 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2"><Clock size={16} className="text-primary-600" />Getting Started</h3>
          <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
            <p>1. Configure Firebase credentials in <code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">.env</code></p>
            <p>2. Create admin user in Firebase Console</p>
            <p>3. Apply Firestore security rules from <code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">firestore.rules</code></p>
            <p>4. Start adding content via the sidebar</p>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
            <p className="text-xs text-gray-400">All changes are reflected on the live website immediately.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

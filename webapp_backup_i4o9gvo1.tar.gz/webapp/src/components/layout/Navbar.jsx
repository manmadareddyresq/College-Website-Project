import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Menu, X, Sun, Moon, Search, ChevronDown, GraduationCap,
  BookOpen, Users, Building2, Trophy, Image, Phone, Newspaper,
  Calendar, FileText, Clock, Award, Shield, Download, MessageSquare,
  Briefcase, FlaskConical, Mic
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useSearch } from '../../context/SearchContext';

const NAV_ITEMS = [
  { label: 'Home', path: '/' },
  {
    label: 'About',
    children: [
      { label: 'About UCMH', path: '/about', icon: Building2 },
      { label: 'Vision & Mission', path: '/vision-mission', icon: Award },
      { label: 'Administration', path: '/administration', icon: Users },
    ],
  },
  {
    label: 'Academics',
    children: [
      { label: 'Courses', path: '/courses', icon: GraduationCap },
      { label: 'Academics', path: '/academics', icon: BookOpen },
      { label: 'Research', path: '/research', icon: FlaskConical },
      { label: 'Mentor-Mentee', path: '/mentor-mentee', icon: Users },
    ],
  },
  {
    label: 'People',
    children: [
      { label: 'Faculty', path: '/faculty', icon: Users },
      { label: 'Alumni', path: '/alumni', icon: Award },
    ],
  },
  {
    label: 'Campus',
    children: [
      { label: 'Facilities', path: '/facilities', icon: Building2 },
      { label: 'Sports', path: '/sports', icon: Trophy },
      { label: 'Gallery', path: '/gallery', icon: Image },
    ],
  },
  {
    label: 'Updates',
    children: [
      { label: 'News', path: '/news', icon: Newspaper },
      { label: 'Events', path: '/events', icon: Calendar },
      { label: 'Circulars', path: '/circulars', icon: FileText },
      { label: 'Results', path: '/results', icon: Award },
      { label: 'Time Tables', path: '/timetables', icon: Clock },
    ],
  },
  {
    label: 'More',
    children: [
      { label: 'Placement Cell', path: '/placements', icon: Briefcase },
      { label: 'Media', path: '/media', icon: Mic },
      { label: 'Downloads', path: '/downloads', icon: Download },
      { label: 'Anti-Ragging', path: '/anti-ragging', icon: Shield },
      { label: 'Feedback', path: '/feedback', icon: MessageSquare },
    ],
  },
  { label: 'Contact', path: '/contact' },
];

const DropdownMenu = ({ items, isOpen }) => (
  <AnimatePresence>
    {isOpen && (
      <motion.div
        initial={{ opacity: 0, y: 8, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 8, scale: 0.96 }}
        transition={{ duration: 0.15 }}
        className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-52 glass-card rounded-2xl p-2 z-50"
      >
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.path}
              to={item.path}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-primary-50 dark:hover:bg-primary-900/20 text-gray-700 dark:text-gray-300 hover:text-primary-600 dark:hover:text-primary-400 transition-colors duration-150 text-sm font-medium"
            >
              {Icon && <Icon size={16} className="text-primary-500 shrink-0" />}
              {item.label}
            </Link>
          );
        })}
      </motion.div>
    )}
  </AnimatePresence>
);

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [expandedMobile, setExpandedMobile] = useState(null);
  const { isDark, toggleTheme } = useTheme();
  const { openSearch } = useSearch();
  const location = useLocation();
  const navigate = useNavigate();
  const dropdownRef = useRef(null);
  const timerRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setActiveDropdown(null);
  }, [location.pathname]);

  const handleMouseEnter = (label) => {
    clearTimeout(timerRef.current);
    setActiveDropdown(label);
  };

  const handleMouseLeave = () => {
    timerRef.current = setTimeout(() => setActiveDropdown(null), 150);
  };

  return (
    <>
      {/* Top bar */}
      <div className="bg-primary-900 text-primary-100 text-xs py-1.5 px-4 text-center hidden md:block">
        Jawaharlal Nehru Technological University Hyderabad | Kukatpally, Hyderabad - 500085, Telangana, India
      </div>

      <nav
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-white/90 dark:bg-gray-950/90 backdrop-blur-xl shadow-lg border-b border-gray-200/50 dark:border-gray-800/50'
            : 'bg-white dark:bg-gray-950 border-b border-gray-100 dark:border-gray-900'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-600 to-primary-800 rounded-xl flex items-center justify-center shadow-glow group-hover:shadow-glow-lg transition-shadow">
                <GraduationCap className="text-white" size={22} />
              </div>
              <div>
                <span className="font-bold text-gray-900 dark:text-white text-sm leading-tight block">UCMH</span>
                <span className="text-xs text-gray-500 dark:text-gray-400 leading-tight block hidden sm:block">Hyderabad</span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-1" ref={dropdownRef}>
              {NAV_ITEMS.map((item) =>
                item.children ? (
                  <div
                    key={item.label}
                    className="relative"
                    onMouseEnter={() => handleMouseEnter(item.label)}
                    onMouseLeave={handleMouseLeave}
                  >
                    <button className="flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium text-gray-600 dark:text-gray-300 hover:text-primary-600 dark:hover:text-primary-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-150">
                      {item.label}
                      <ChevronDown size={14} className={`transition-transform duration-200 ${activeDropdown === item.label ? 'rotate-180' : ''}`} />
                    </button>
                    <DropdownMenu items={item.children} isOpen={activeDropdown === item.label} />
                  </div>
                ) : (
                  <Link
                    key={item.label}
                    to={item.path}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
                      location.pathname === item.path
                        ? 'text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/20'
                        : 'text-gray-600 dark:text-gray-300 hover:text-primary-600 dark:hover:text-primary-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                    }`}
                  >
                    {item.label}
                  </Link>
                )
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={openSearch}
                className="p-2 rounded-lg text-gray-500 hover:text-primary-600 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
                aria-label="Search"
              >
                <Search size={18} />
              </button>
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg text-gray-500 hover:text-primary-600 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
                aria-label="Toggle theme"
              >
                {isDark ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              <Link
                to="/admin"
                className="hidden sm:inline-flex btn-primary text-sm px-4 py-2"
              >
                Admin
              </Link>
              <button
                className="lg:hidden p-2 rounded-lg text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
                onClick={() => setMobileOpen(!mobileOpen)}
                aria-label="Menu"
              >
                {mobileOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25 }}
              className="lg:hidden border-t border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-950 overflow-y-auto max-h-[80vh] scrollbar-thin"
            >
              <div className="px-4 py-3 space-y-1">
                {NAV_ITEMS.map((item) =>
                  item.children ? (
                    <div key={item.label}>
                      <button
                        onClick={() => setExpandedMobile(expandedMobile === item.label ? null : item.label)}
                        className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                      >
                        {item.label}
                        <ChevronDown size={14} className={`transition-transform ${expandedMobile === item.label ? 'rotate-180' : ''}`} />
                      </button>
                      <AnimatePresence>
                        {expandedMobile === item.label && (
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: 'auto' }}
                            exit={{ height: 0 }}
                            className="overflow-hidden pl-4 space-y-1 mt-1"
                          >
                            {item.children.map((child) => {
                              const Icon = child.icon;
                              return (
                                <Link
                                  key={child.path}
                                  to={child.path}
                                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-gray-600 dark:text-gray-400 hover:text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors"
                                >
                                  {Icon && <Icon size={14} />}
                                  {child.label}
                                </Link>
                              );
                            })}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ) : (
                    <Link
                      key={item.label}
                      to={item.path}
                      className="block px-3 py-2.5 rounded-xl text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                    >
                      {item.label}
                    </Link>
                  )
                )}
                <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                  <Link to="/admin" className="btn-primary w-full justify-center text-sm">
                    Admin Panel
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </>
  );
}

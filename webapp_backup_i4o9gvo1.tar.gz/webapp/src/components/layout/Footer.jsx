import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  GraduationCap, MapPin, Phone, Mail, Globe,
  ArrowRight, Share2, MessageSquare, ExternalLink,
  Play
} from 'lucide-react';

// Social icon aliases for compatibility
const Facebook = Share2;
const Twitter = MessageSquare;
const Instagram = ExternalLink;
const Linkedin = ExternalLink;
const Youtube = Play;

const LINKS = {
  quickLinks: [
    { label: 'About UCMH', path: '/about' },
    { label: 'Courses', path: '/courses' },
    { label: 'Faculty', path: '/faculty' },
    { label: 'Placements', path: '/placements' },
    { label: 'Research', path: '/research' },
  ],
  academics: [
    { label: 'MBA Program', path: '/courses' },
    { label: 'BBA Program', path: '/courses' },
    { label: 'PhD Program', path: '/courses' },
    { label: 'Academics', path: '/academics' },
    { label: 'Mentor-Mentee', path: '/mentor-mentee' },
  ],
  campus: [
    { label: 'Facilities', path: '/facilities' },
    { label: 'Sports', path: '/sports' },
    { label: 'Gallery', path: '/gallery' },
    { label: 'Alumni', path: '/alumni' },
    { label: 'Anti-Ragging', path: '/anti-ragging' },
  ],
};

const SOCIAL = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Youtube, href: '#', label: 'YouTube' },
];

export default function Footer() {
  return (
    <footer className="bg-gray-950 dark:bg-black text-gray-300 pt-16 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-gray-800">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-600 to-primary-800 rounded-xl flex items-center justify-center">
                <GraduationCap className="text-white" size={22} />
              </div>
              <div>
                <p className="font-bold text-white text-base">UCMH</p>
                <p className="text-xs text-gray-400">University College of Management Hyderabad</p>
              </div>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed mb-5">
              Affiliated with Jawaharlal Nehru Technological University Hyderabad,
              UCMH is a premier management institution committed to academic excellence,
              innovation, and holistic development.
            </p>
            {/* Contact */}
            <div className="space-y-2.5 text-sm">
              <a href="https://maps.google.com" target="_blank" rel="noreferrer" className="flex items-start gap-2.5 text-gray-400 hover:text-primary-400 transition-colors">
                <MapPin size={15} className="mt-0.5 shrink-0 text-primary-500" />
                Kukatpally, Hyderabad - 500085, Telangana, India
              </a>
              <a href="tel:+914023456789" className="flex items-center gap-2.5 text-gray-400 hover:text-primary-400 transition-colors">
                <Phone size={15} className="text-primary-500" />
                +91 40 2345 6789
              </a>
              <a href="mailto:info@ucmh.edu.in" className="flex items-center gap-2.5 text-gray-400 hover:text-primary-400 transition-colors">
                <Mail size={15} className="text-primary-500" />
                info@ucmh.edu.in
              </a>
              <a href="https://www.ucmh.edu.in" className="flex items-center gap-2.5 text-gray-400 hover:text-primary-400 transition-colors">
                <Globe size={15} className="text-primary-500" />
                www.ucmh.edu.in
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-2">
              {LINKS.quickLinks.map(l => (
                <li key={l.path}>
                  <Link to={l.path} className="text-sm text-gray-400 hover:text-primary-400 transition-colors flex items-center gap-1.5 group">
                    <ArrowRight size={12} className="opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all" />
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Academics */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Academics</h4>
            <ul className="space-y-2">
              {LINKS.academics.map(l => (
                <li key={l.path}>
                  <Link to={l.path} className="text-sm text-gray-400 hover:text-primary-400 transition-colors flex items-center gap-1.5 group">
                    <ArrowRight size={12} className="opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all" />
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Campus */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Campus Life</h4>
            <ul className="space-y-2">
              {LINKS.campus.map(l => (
                <li key={l.path}>
                  <Link to={l.path} className="text-sm text-gray-400 hover:text-primary-400 transition-colors flex items-center gap-1.5 group">
                    <ArrowRight size={12} className="opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all" />
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-500 text-center sm:text-left">
            © {new Date().getFullYear()} University College of Management Hyderabad. All rights reserved.
          </p>
          <div className="flex items-center gap-3">
            {SOCIAL.map(({ icon: Icon, href, label }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                className="w-8 h-8 rounded-lg bg-gray-800 hover:bg-primary-700 flex items-center justify-center text-gray-400 hover:text-white transition-all duration-200"
              >
                <Icon size={14} />
              </a>
            ))}
          </div>
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <Link to="/anti-ragging" className="hover:text-primary-400 transition-colors">Anti-Ragging</Link>
            <Link to="/feedback" className="hover:text-primary-400 transition-colors">Feedback</Link>
            <Link to="/admin" className="hover:text-primary-400 transition-colors">Admin</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

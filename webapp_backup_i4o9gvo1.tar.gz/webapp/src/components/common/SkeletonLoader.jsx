import React from 'react';

export const SkeletonCard = () => (
  <div className="card p-6 animate-pulse">
    <div className="skeleton h-40 w-full rounded-xl mb-4" />
    <div className="skeleton h-4 w-3/4 mb-2" />
    <div className="skeleton h-3 w-full mb-1" />
    <div className="skeleton h-3 w-5/6" />
  </div>
);

export const SkeletonList = ({ count = 5 }) => (
  <div className="space-y-4">
    {Array.from({ length: count }).map((_, i) => (
      <div key={i} className="card p-4 animate-pulse flex gap-4">
        <div className="skeleton h-12 w-12 rounded-xl shrink-0" />
        <div className="flex-1 space-y-2">
          <div className="skeleton h-4 w-2/3" />
          <div className="skeleton h-3 w-full" />
          <div className="skeleton h-3 w-1/2" />
        </div>
      </div>
    ))}
  </div>
);

export const SkeletonText = ({ lines = 3 }) => (
  <div className="animate-pulse space-y-2">
    {Array.from({ length: lines }).map((_, i) => (
      <div
        key={i}
        className="skeleton h-4"
        style={{ width: i === lines - 1 ? '60%' : '100%' }}
      />
    ))}
  </div>
);

export const SkeletonFacultyCard = () => (
  <div className="card p-6 animate-pulse text-center">
    <div className="skeleton w-24 h-24 rounded-full mx-auto mb-4" />
    <div className="skeleton h-4 w-3/4 mx-auto mb-2" />
    <div className="skeleton h-3 w-1/2 mx-auto mb-1" />
    <div className="skeleton h-3 w-2/3 mx-auto" />
  </div>
);

export default function SkeletonLoader({ type = 'card', count = 3 }) {
  if (type === 'list') return <SkeletonList count={count} />;
  if (type === 'faculty') return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {Array.from({ length: count }).map((_, i) => <SkeletonFacultyCard key={i} />)}
    </div>
  );
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: count }).map((_, i) => <SkeletonCard key={i} />)}
    </div>
  );
}

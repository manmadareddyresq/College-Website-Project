import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, ArrowRight } from 'lucide-react';
import { useSearch } from '../../context/SearchContext';

const categoryColors = {
  Course: 'badge-primary',
  Page: 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300',
  Dynamic: 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300',
  Feature: 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300',
  Academic: 'bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-300',
  People: 'bg-pink-100 dark:bg-pink-900/30 text-pink-700 dark:text-pink-300',
  Policy: 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300',
};

export default function SearchModal() {
  const { query, results, isOpen, search, closeSearch } = useSearch();
  const inputRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape') closeSearch();
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        isOpen ? closeSearch() : null;
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, closeSearch]);

  const handleSelect = (path) => {
    navigate(path);
    closeSearch();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4"
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={closeSearch} />

          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.96 }}
            transition={{ duration: 0.2 }}
            className="relative w-full max-w-2xl glass-card rounded-2xl overflow-hidden"
          >
            {/* Search input */}
            <div className="flex items-center gap-3 p-4 border-b border-gray-100 dark:border-gray-800">
              <Search size={20} className="text-primary-500 shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => search(e.target.value)}
                placeholder="Search pages, courses, people..."
                className="flex-1 bg-transparent text-gray-900 dark:text-gray-100 placeholder-gray-400 outline-none text-base"
              />
              <button onClick={closeSearch} className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                <X size={18} className="text-gray-400" />
              </button>
            </div>

            {/* Results */}
            <div className="max-h-96 overflow-y-auto scrollbar-thin">
              {query && results.length === 0 ? (
                <div className="p-8 text-center text-gray-400">
                  <Search size={32} className="mx-auto mb-3 opacity-30" />
                  <p>No results found for "{query}"</p>
                </div>
              ) : results.length > 0 ? (
                <div className="p-2">
                  {results.map((item) => (
                    <button
                      key={item.path + item.title}
                      onClick={() => handleSelect(item.path)}
                      className="w-full flex items-center justify-between gap-3 px-4 py-3 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-left group"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-gray-900 dark:text-gray-100 text-sm">{item.title}</p>
                        <p className="text-xs text-gray-500 mt-0.5 truncate">{item.description}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={`badge text-xs ${categoryColors[item.category] || 'badge-primary'}`}>
                          {item.category}
                        </span>
                        <ArrowRight size={14} className="text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="p-6 text-center text-gray-400 text-sm">
                  <p className="font-medium mb-1">Quick navigation</p>
                  <p>Type to search across all pages and content</p>
                </div>
              )}
            </div>

            {/* Footer hint */}
            <div className="px-4 py-2.5 bg-gray-50 dark:bg-gray-900/50 border-t border-gray-100 dark:border-gray-800 flex items-center gap-3 text-xs text-gray-400">
              <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 bg-gray-200 dark:bg-gray-700 rounded text-gray-600 dark:text-gray-300">↑↓</kbd> navigate</span>
              <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 bg-gray-200 dark:bg-gray-700 rounded text-gray-600 dark:text-gray-300">↵</kbd> select</span>
              <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 bg-gray-200 dark:bg-gray-700 rounded text-gray-600 dark:text-gray-300">ESC</kbd> close</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, X, Send, Bot, User } from 'lucide-react';

const INITIAL_MESSAGES = [
  {
    role: 'bot',
    text: 'Hello! I\'m the UCMH virtual assistant. How can I help you today?',
  },
];

const QUICK_REPLIES = [
  'Tell me about MBA program',
  'Admission process',
  'Campus facilities',
  'Contact info',
];

const BOT_RESPONSES = {
  'mba': 'UCMH offers MBA (Regular-ICET), MBA Part-Time (PTPG), and MBA in collaboration with Carnegie Mellon University, USA. Visit our Courses page for detailed information.',
  'admission': 'For MBA: Admission through ICET (AP/TS). For BBA: Direct admission based on 10+2 marks. Contact our admissions office at admissions@ucmh.edu.in for details.',
  'facilities': 'UCMH offers world-class facilities including a digital library, computer labs, conference halls, sports complex, cafeteria, and Wi-Fi campus. Visit our Facilities page for more.',
  'contact': 'Phone: +91 40 2345 6789\nEmail: info@ucmh.edu.in\nAddress: Kukatpally, Hyderabad - 500085, Telangana',
  'default': 'Thank you for your question! For detailed information, please visit the relevant section of our website or contact us at info@ucmh.edu.in or +91 40 2345 6789.',
};

function getBotResponse(input) {
  const lower = input.toLowerCase();
  if (lower.includes('mba') || lower.includes('master')) return BOT_RESPONSES.mba;
  if (lower.includes('admission') || lower.includes('apply') || lower.includes('icet')) return BOT_RESPONSES.admission;
  if (lower.includes('facilit') || lower.includes('lab') || lower.includes('library')) return BOT_RESPONSES.facilities;
  if (lower.includes('contact') || lower.includes('phone') || lower.includes('email') || lower.includes('address')) return BOT_RESPONSES.contact;
  return BOT_RESPONSES.default;
}

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const sendMessage = (text) => {
    const msg = text || input.trim();
    if (!msg) return;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: msg }]);
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, { role: 'bot', text: getBotResponse(msg) }]);
    }, 1000 + Math.random() * 500);
  };

  return (
    <>
      {/* FAB */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-primary-600 hover:bg-primary-700 text-white rounded-2xl shadow-glow flex items-center justify-center transition-colors"
        aria-label="Chat with us"
      >
        <AnimatePresence mode="wait">
          {isOpen
            ? <motion.div key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.15 }}><X size={22} /></motion.div>
            : <motion.div key="chat" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.15 }}><MessageSquare size={22} /></motion.div>
          }
        </AnimatePresence>
      </motion.button>

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-24 right-6 z-50 w-80 sm:w-96 glass-card rounded-2xl overflow-hidden flex flex-col"
            style={{ maxHeight: '500px' }}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-primary-700 to-primary-600 px-4 py-3 flex items-center gap-3">
              <div className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center">
                <Bot size={18} className="text-white" />
              </div>
              <div>
                <p className="text-white font-semibold text-sm">UCMH Assistant</p>
                <p className="text-primary-200 text-xs flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full" />
                  Online
                </p>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin bg-white dark:bg-gray-900">
              {messages.map((msg, i) => (
                <div key={i} className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${msg.role === 'bot' ? 'bg-primary-100 dark:bg-primary-900/40' : 'bg-gray-200 dark:bg-gray-700'}`}>
                    {msg.role === 'bot' ? <Bot size={14} className="text-primary-600 dark:text-primary-400" /> : <User size={14} className="text-gray-600 dark:text-gray-300" />}
                  </div>
                  <div className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm leading-relaxed whitespace-pre-line ${
                    msg.role === 'bot'
                      ? 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-tl-sm'
                      : 'bg-primary-600 text-white rounded-tr-sm'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex gap-2">
                  <div className="w-7 h-7 rounded-full bg-primary-100 dark:bg-primary-900/40 flex items-center justify-center">
                    <Bot size={14} className="text-primary-600" />
                  </div>
                  <div className="bg-gray-100 dark:bg-gray-800 px-4 py-3 rounded-2xl rounded-tl-sm flex items-center gap-1">
                    {[0,1,2].map(i => (
                      <span key={i} className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Quick replies */}
            <div className="px-3 py-2 flex gap-1.5 overflow-x-auto scrollbar-thin bg-gray-50 dark:bg-gray-900/50">
              {QUICK_REPLIES.map(r => (
                <button
                  key={r}
                  onClick={() => sendMessage(r)}
                  className="whitespace-nowrap text-xs px-3 py-1.5 rounded-full border border-primary-200 dark:border-primary-700 text-primary-600 dark:text-primary-400 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors"
                >
                  {r}
                </button>
              ))}
            </div>

            {/* Input */}
            <div className="p-3 bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 flex gap-2">
              <input
                type="text"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendMessage()}
                placeholder="Type a message..."
                className="flex-1 input-field text-sm py-2"
              />
              <button
                onClick={() => sendMessage()}
                disabled={!input.trim()}
                className="w-10 h-10 bg-primary-600 hover:bg-primary-700 disabled:opacity-40 text-white rounded-xl flex items-center justify-center transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

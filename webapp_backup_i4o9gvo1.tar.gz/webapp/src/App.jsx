import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SearchProvider } from './context/SearchContext';

// Layout
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import SearchModal from './components/ui/SearchModal';
import ChatBot from './components/ui/ChatBot';

// Pages - Lazy loaded for code splitting
const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const VisionMission = lazy(() => import('./pages/VisionMission'));
const Administration = lazy(() => import('./pages/Administration'));
const Contact = lazy(() => import('./pages/Contact'));
const Courses = lazy(() => import('./pages/Courses'));
const Academics = lazy(() => import('./pages/Academics'));
const Faculty = lazy(() => import('./pages/Faculty'));
const Research = lazy(() => import('./pages/Research'));
const MentorMentee = lazy(() => import('./pages/MentorMentee'));
const Facilities = lazy(() => import('./pages/Facilities'));
const Sports = lazy(() => import('./pages/Sports'));
const Gallery = lazy(() => import('./pages/Gallery'));
const News = lazy(() => import('./pages/News'));
const Events = lazy(() => import('./pages/Events'));
const Circulars = lazy(() => import('./pages/Circulars'));
const Results = lazy(() => import('./pages/Results'));
const Timetables = lazy(() => import('./pages/Timetables'));
const Placements = lazy(() => import('./pages/Placements'));
const Alumni = lazy(() => import('./pages/Alumni'));
const Media = lazy(() => import('./pages/Media'));
const Downloads = lazy(() => import('./pages/Downloads'));
const AntiRagging = lazy(() => import('./pages/AntiRagging'));
const Feedback = lazy(() => import('./pages/Feedback'));

// Admin Pages
const AdminLogin = lazy(() => import('./admin/pages/AdminLogin'));
const AdminDashboard = lazy(() => import('./admin/pages/AdminDashboard'));
const AdminNews = lazy(() => import('./admin/pages/AdminNews'));
const AdminEvents = lazy(() => import('./admin/pages/AdminEvents'));
const AdminFaculty = lazy(() => import('./admin/pages/AdminFaculty'));
const AdminGallery = lazy(() => import('./admin/pages/AdminGallery'));
const AdminCourses = lazy(() => import('./admin/pages/AdminCourses'));
const AdminFeedback = lazy(() => import('./admin/pages/AdminFeedback'));
const AdminCirculars = lazy(() => import('./admin/pages/AdminCirculars'));
const AdminLayout = lazy(() => import('./admin/components/AdminLayout'));

// Loading fallback
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-950">
    <div className="flex flex-col items-center gap-4">
      <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
      <p className="text-sm text-gray-500 dark:text-gray-400">Loading...</p>
    </div>
  </div>
);

// Protected admin route
function ProtectedAdminRoute({ children }) {
  const { user, loading, adminVerified } = useAuth();

  if (loading) return <PageLoader />;
  if (!user) return <Navigate to="/admin" replace />;

  // Allow access if Firebase is not configured (demo mode)
  const isDemo = !import.meta.env.VITE_FIREBASE_API_KEY || import.meta.env.VITE_FIREBASE_API_KEY === 'your-api-key';
  if (!adminVerified && !isDemo) return <Navigate to="/admin" replace />;

  return children;
}

// Public layout wrapper
function PublicLayout({ children }) {
  return (
    <>
      <Navbar />
      <main className="min-h-screen">
        <Suspense fallback={<PageLoader />}>
          {children}
        </Suspense>
      </main>
      <Footer />
      <ChatBot />
      <SearchModal />
    </>
  );
}

// Admin layout wrapper with protection
function AdminProtectedLayout({ children }) {
  return (
    <ProtectedAdminRoute>
      <Suspense fallback={<PageLoader />}>
        <AdminLayout>
          {children}
        </AdminLayout>
      </Suspense>
    </ProtectedAdminRoute>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <SearchProvider>
            <Toaster
              position="top-right"
              toastOptions={{
                duration: 3000,
                style: {
                  borderRadius: '12px',
                  background: 'var(--toast-bg)',
                  color: 'var(--toast-color)',
                },
              }}
            />
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<PublicLayout><Home /></PublicLayout>} />
              <Route path="/about" element={<PublicLayout><About /></PublicLayout>} />
              <Route path="/vision-mission" element={<PublicLayout><VisionMission /></PublicLayout>} />
              <Route path="/administration" element={<PublicLayout><Administration /></PublicLayout>} />
              <Route path="/contact" element={<PublicLayout><Contact /></PublicLayout>} />

              {/* Academic Routes */}
              <Route path="/courses" element={<PublicLayout><Courses /></PublicLayout>} />
              <Route path="/academics" element={<PublicLayout><Academics /></PublicLayout>} />
              <Route path="/faculty" element={<PublicLayout><Faculty /></PublicLayout>} />
              <Route path="/research" element={<PublicLayout><Research /></PublicLayout>} />
              <Route path="/mentor-mentee" element={<PublicLayout><MentorMentee /></PublicLayout>} />

              {/* Campus Routes */}
              <Route path="/facilities" element={<PublicLayout><Facilities /></PublicLayout>} />
              <Route path="/sports" element={<PublicLayout><Sports /></PublicLayout>} />
              <Route path="/gallery" element={<PublicLayout><Gallery /></PublicLayout>} />
              <Route path="/alumni" element={<PublicLayout><Alumni /></PublicLayout>} />

              {/* Dynamic Routes */}
              <Route path="/news" element={<PublicLayout><News /></PublicLayout>} />
              <Route path="/events" element={<PublicLayout><Events /></PublicLayout>} />
              <Route path="/circulars" element={<PublicLayout><Circulars /></PublicLayout>} />
              <Route path="/results" element={<PublicLayout><Results /></PublicLayout>} />
              <Route path="/timetables" element={<PublicLayout><Timetables /></PublicLayout>} />

              {/* Feature Routes */}
              <Route path="/placements" element={<PublicLayout><Placements /></PublicLayout>} />
              <Route path="/media" element={<PublicLayout><Media /></PublicLayout>} />
              <Route path="/downloads" element={<PublicLayout><Downloads /></PublicLayout>} />
              <Route path="/anti-ragging" element={<PublicLayout><AntiRagging /></PublicLayout>} />
              <Route path="/feedback" element={<PublicLayout><Feedback /></PublicLayout>} />

              {/* Admin Routes */}
              <Route path="/admin" element={<Suspense fallback={<PageLoader />}><AdminLogin /></Suspense>} />
              <Route path="/admin/dashboard" element={<AdminProtectedLayout><AdminDashboard /></AdminProtectedLayout>} />
              <Route path="/admin/news" element={<AdminProtectedLayout><AdminNews /></AdminProtectedLayout>} />
              <Route path="/admin/events" element={<AdminProtectedLayout><AdminEvents /></AdminProtectedLayout>} />
              <Route path="/admin/faculty" element={<AdminProtectedLayout><AdminFaculty /></AdminProtectedLayout>} />
              <Route path="/admin/gallery" element={<AdminProtectedLayout><AdminGallery /></AdminProtectedLayout>} />
              <Route path="/admin/courses" element={<AdminProtectedLayout><AdminCourses /></AdminProtectedLayout>} />
              <Route path="/admin/feedback" element={<AdminProtectedLayout><AdminFeedback /></AdminProtectedLayout>} />
              <Route path="/admin/circulars" element={<AdminProtectedLayout><AdminCirculars /></AdminProtectedLayout>} />

              {/* 404 */}
              <Route path="*" element={
                <PublicLayout>
                  <div className="min-h-screen flex items-center justify-center">
                    <div className="text-center">
                      <h1 className="text-8xl font-black text-primary-600 dark:text-primary-400 mb-4">404</h1>
                      <p className="text-xl font-bold text-gray-900 dark:text-white mb-2">Page Not Found</p>
                      <p className="text-gray-500 mb-8">The page you're looking for doesn't exist.</p>
                      <a href="/" className="btn-primary">Go Home</a>
                    </div>
                  </div>
                </PublicLayout>
              } />
            </Routes>
          </SearchProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}

import React, { createContext, useContext, useState, useCallback } from 'react';

const SearchContext = createContext();

const SEARCHABLE_CONTENT = [
  { title: 'MBA Program', description: 'Master of Business Administration - Regular (ICET)', path: '/courses', category: 'Course' },
  { title: 'MBA Part-Time (PTPG)', description: 'Part-time MBA program for working professionals', path: '/courses', category: 'Course' },
  { title: 'MBA + CMU Collaboration', description: 'International MBA with Carnegie Mellon University', path: '/courses', category: 'Course' },
  { title: 'PhD Program', description: 'Doctoral research programs', path: '/courses', category: 'Course' },
  { title: 'BBA Regular', description: 'Bachelor of Business Administration', path: '/courses', category: 'Course' },
  { title: 'BBA Data Analytics', description: 'BBA with specialization in Data Analytics', path: '/courses', category: 'Course' },
  { title: 'About UCMH', description: 'About University College of Management Hyderabad', path: '/about', category: 'Page' },
  { title: 'Vision & Mission', description: 'Our vision, mission and core values', path: '/vision-mission', category: 'Page' },
  { title: 'Administration', description: 'Meet our administration team including Principal Dr. Sindhu', path: '/administration', category: 'Page' },
  { title: 'Faculty', description: 'Our distinguished faculty members', path: '/faculty', category: 'People' },
  { title: 'Placement Cell', description: 'Career services and placement assistance', path: '/placements', category: 'Feature' },
  { title: 'Research', description: 'Research activities and publications', path: '/research', category: 'Academic' },
  { title: 'Facilities', description: 'World-class campus facilities', path: '/facilities', category: 'Page' },
  { title: 'Alumni', description: 'Our alumni network', path: '/alumni', category: 'Page' },
  { title: 'Sports', description: 'Sports and extracurricular activities', path: '/sports', category: 'Page' },
  { title: 'Photo Gallery', description: 'Campus photos and event galleries', path: '/gallery', category: 'Feature' },
  { title: 'News', description: 'Latest news and updates', path: '/news', category: 'Dynamic' },
  { title: 'Events', description: 'Upcoming and past events', path: '/events', category: 'Dynamic' },
  { title: 'Circulars', description: 'Official circulars and notices', path: '/circulars', category: 'Dynamic' },
  { title: 'Results', description: 'Examination results', path: '/results', category: 'Dynamic' },
  { title: 'Time Tables', description: 'Academic timetables', path: '/timetables', category: 'Dynamic' },
  { title: 'Mentor-Mentee', description: 'Mentor-Mentee program details', path: '/mentor-mentee', category: 'Academic' },
  { title: 'Anti-Ragging', description: 'Anti-ragging policy and committee', path: '/anti-ragging', category: 'Policy' },
  { title: 'Downloads', description: 'Important documents and forms', path: '/downloads', category: 'Feature' },
  { title: 'Feedback', description: 'Share your feedback with us', path: '/feedback', category: 'Feature' },
  { title: 'Contact', description: 'Contact information and location', path: '/contact', category: 'Page' },
  { title: 'Media', description: 'Media coverage and press releases', path: '/media', category: 'Page' },
];

export const SearchProvider = ({ children }) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [results, setResults] = useState([]);

  const search = useCallback((searchQuery) => {
    setQuery(searchQuery);
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }
    const q = searchQuery.toLowerCase();
    const filtered = SEARCHABLE_CONTENT.filter(item =>
      item.title.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q)
    ).slice(0, 8);
    setResults(filtered);
  }, []);

  const openSearch = () => setIsOpen(true);
  const closeSearch = () => { setIsOpen(false); setQuery(''); setResults([]); };

  return (
    <SearchContext.Provider value={{ query, results, isOpen, search, openSearch, closeSearch }}>
      {children}
    </SearchContext.Provider>
  );
};

export const useSearch = () => {
  const ctx = useContext(SearchContext);
  if (!ctx) throw new Error('useSearch must be inside SearchProvider');
  return ctx;
};

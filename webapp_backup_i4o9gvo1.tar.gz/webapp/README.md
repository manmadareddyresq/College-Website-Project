# UCMH — University College of Management Hyderabad

> **Production-ready, full-stack modern college website** built with React + Vite + Tailwind CSS + Firebase

## 🌐 Live URL
After deployment: `https://your-project.vercel.app`

---

## ✅ Features Implemented

### Core Pages
- 🏠 **Home** — Hero with animated gradient, stats, marquee ticker, courses, news, events, CTA
- ℹ️ **About** — College history, values, timeline
- 🎯 **Vision & Mission** — Vision/Mission cards, quality policy, pillars
- 👥 **Administration** — Principal Dr. Sindhu featured card + full team
- 📞 **Contact** — Google Maps embed + feedback form

### Academic Modules
- 🎓 **Courses** — MBA (ICET, PTPG, CMU), PhD, BBA Regular, BBA Data Analytics with expandable cards
- 📚 **Academics** — Framework overview, academic calendar
- 🔬 **Research** — Publications, research areas, funding
- 👨‍🏫 **Faculty** — Searchable & filterable faculty grid
- 🤝 **Mentor-Mentee** — Program details, active mentor list

### Campus Life
- 🏗️ **Facilities** — 8 facility cards (Library, Labs, Sports, etc.)
- 🏆 **Sports** — Sports list, achievements, coordinator info
- 🖼️ **Gallery** — Filterable photo grid with lightbox viewer
- 🎓 **Alumni** — Spotlight grid, stats, registration CTA

### Dynamic Modules (Firebase-Connected)
- 📰 **News** — Filterable news cards with categories
- 📅 **Events** — Upcoming/past tab with date badges
- 📋 **Circulars** — Official notices with download
- 🏅 **Results** — JNTUH results link + hall ticket lookup
- 🕐 **Timetables** — Interactive timetable viewer

### Feature Modules
- 💼 **Placements** — Stats, recruiter grid, contact CTA
- 🎙️ **Media** — Press coverage listing
- ⬇️ **Downloads** — Searchable document library
- 🛡️ **Anti-Ragging** — Policy, committee, emergency contacts
- ⭐ **Feedback** — Star rating + form with Firebase storage

### Admin Panel (`/admin`)
- 🔐 Secure login with Firebase Auth
- 📊 Dashboard with content stats
- 📝 CRUD: News, Events, Faculty, Gallery, Courses, Circulars
- 💬 Feedback viewer with delete
- 🔒 Role-based access control

### UX/UI Features
- 🌙 Dark/Light mode toggle (persistent)
- 🔍 Global search modal (Ctrl+K)
- 🤖 Chatbot UI with quick replies
- ⚡ Skeleton loaders
- 🎞️ Framer Motion animations
- 📱 Fully mobile responsive
- 📢 Marquee announcement ticker

---

## 🏗️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite |
| Styling | Tailwind CSS 3 |
| Animations | Framer Motion |
| Routing | React Router DOM v6 |
| Backend/DB | Firebase (Firestore + Auth + Storage) |
| Icons | Lucide React |
| Toasts | React Hot Toast |

---

## 📂 Folder Structure

```
src/
├── admin/
│   ├── components/
│   │   └── AdminLayout.jsx
│   └── pages/
│       ├── AdminLogin.jsx
│       ├── AdminDashboard.jsx
│       ├── AdminNews.jsx
│       ├── AdminEvents.jsx
│       ├── AdminFaculty.jsx
│       ├── AdminGallery.jsx
│       ├── AdminCourses.jsx
│       ├── AdminFeedback.jsx
│       └── AdminCirculars.jsx
├── components/
│   ├── layout/
│   │   ├── Navbar.jsx
│   │   └── Footer.jsx
│   ├── ui/
│   │   ├── SearchModal.jsx
│   │   └── ChatBot.jsx
│   └── common/
│       ├── PageHeader.jsx
│       └── SkeletonLoader.jsx
├── context/
│   ├── ThemeContext.jsx
│   ├── AuthContext.jsx
│   └── SearchContext.jsx
├── pages/
│   ├── Home.jsx
│   ├── About.jsx
│   ├── VisionMission.jsx
│   ├── Administration.jsx
│   ├── Contact.jsx
│   ├── Courses.jsx
│   ├── Academics.jsx
│   ├── Faculty.jsx
│   ├── Research.jsx
│   ├── MentorMentee.jsx
│   ├── Facilities.jsx
│   ├── Sports.jsx
│   ├── Gallery.jsx
│   ├── Alumni.jsx
│   ├── News.jsx
│   ├── Events.jsx
│   ├── Circulars.jsx
│   ├── Results.jsx
│   ├── Timetables.jsx
│   ├── Placements.jsx
│   ├── Media.jsx
│   ├── Downloads.jsx
│   ├── AntiRagging.jsx
│   └── Feedback.jsx
└── services/
    ├── firebase.js
    ├── firestore.js
    └── auth.js
```

---

## 🚀 Setup Instructions

### 1. Clone & Install
```bash
git clone <your-repo-url>
cd webapp
npm install
```

### 2. Firebase Setup
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project → Enable **Firestore**, **Authentication** (Email/Password), **Storage**
3. In Authentication → Add Users → Create admin user with email `admin@ucmh.edu.in`
4. Copy Web App credentials to `.env`:

```bash
cp .env.example .env
```

Edit `.env`:
```
VITE_FIREBASE_API_KEY=your-actual-key
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abcdef
VITE_ADMIN_EMAIL=admin@ucmh.edu.in
```

### 3. Apply Firestore Security Rules
```bash
# Install Firebase CLI
npm install -g firebase-tools
firebase login
firebase init firestore
```
Replace `firestore.rules` contents with the file provided, then:
```bash
firebase deploy --only firestore:rules
```

### 4. Run Locally
```bash
npm run dev
```
Visit `http://localhost:5173`

---

## 🌐 Vercel Deployment

### Option 1: Vercel Dashboard
1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com) → Import Repository
3. Set environment variables from `.env`
4. Deploy → Done!

### Option 2: CLI
```bash
npm install -g vercel
vercel --prod
```

### Vercel Environment Variables to Set:
```
VITE_FIREBASE_API_KEY
VITE_FIREBASE_AUTH_DOMAIN
VITE_FIREBASE_PROJECT_ID
VITE_FIREBASE_STORAGE_BUCKET
VITE_FIREBASE_MESSAGING_SENDER_ID
VITE_FIREBASE_APP_ID
VITE_ADMIN_EMAIL
```

---

## 🔥 Firestore Database Structure

```
collections/
├── news/          { title, summary, content, category, imageUrl, createdAt, updatedAt }
├── events/        { title, description, eventDate, venue, time, category, status, createdAt }
├── faculty/       { name, designation, department, qualification, experience, specialization, email, order }
├── gallery/       { title, imageUrl, category, createdAt }
├── courses/       { title, tag, duration, seats, eligibility, desc, fee, order }
├── feedback/      { name, email, role, category, rating, message, type, createdAt }
└── circulars/     { title, type, date, fileUrl, createdAt }
```

---

## 🔐 Admin Access

| Route | Description |
|-------|-------------|
| `/admin` | Login page |
| `/admin/dashboard` | Dashboard overview |
| `/admin/news` | Manage news articles |
| `/admin/events` | Manage events |
| `/admin/faculty` | Manage faculty |
| `/admin/gallery` | Manage photo gallery |
| `/admin/courses` | Manage courses |
| `/admin/feedback` | View feedback |
| `/admin/circulars` | Manage circulars |

---

## 📊 Performance Notes

- Code splitting via React lazy() + Suspense on all routes
- Firebase SDKs lazy-loaded only when needed
- Skeleton loaders for all async content
- Image lazy loading throughout
- Framer Motion animations with GPU acceleration
- Tailwind CSS purges unused styles in production

---

## 🏛️ Institution Info

**University College of Management Hyderabad (UCMH)**
- Affiliated: Jawaharlal Nehru Technological University Hyderabad (JNTUH)
- Location: Kukatpally, Hyderabad - 500085, Telangana, India
- Principal: Dr. Sindhu
- Email: info@ucmh.edu.in | Phone: +91 40 2345 6789

---

*Last Updated: March 2025*
